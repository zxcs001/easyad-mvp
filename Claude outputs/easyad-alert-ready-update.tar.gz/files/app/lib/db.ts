import { allocation, checkDigitalCapacity, listDigitalCommitments, ScheduleError } from "./digital-schedule";
import { addDays, parseDayparts } from "./booking-schedule";
import { createHash, randomUUID } from "node:crypto";
import { readFileSync } from "node:fs";
import path from "node:path";
import { Pool, type PoolClient, type QueryResultRow } from "pg";
import { ApprovalEvent, Booking, Creative, DeviceAlert, DeviceAlertType, DisplayTemplate, InventoryAdvertiserResource, InventoryComment, InventoryItem, InventorySpecification, MediaResource, MembershipRole, Organization, PopLog, Role, Transaction, TransactionStatus, UserStatus, displayTemplates } from "../data";
import { isLocale, type Locale } from "../i18n/config";
import { expectedPlays, splitRevenue } from "../utils";
import { isDigitalInventory } from "./inventory-delivery";

type UserRow = {
  screen_scope?: string[]|null;
  id: string;
  name: string;
  email: string;
  password_hash: string;
  role: Role;
  status?: UserStatus;
  institution_id?: string | null;
  operator_limit?: number;
  created_at: string;
};

type InventoryRow = {
  building: string; department: string; content_visibility: "public"|"private"; advertising_opt_in: boolean; restricted_categories: string[]; reserved_seconds: number; fleet_version:number;
  id: string;
  name: string;
  operator: string;
  format: InventoryItem["format"];
  x: number;
  y: number;
  address: string;
  price: number;
  impressions: number;
  traffic: number;
  income: number;
  audience: string;
  competitor: InventoryItem["competitor"];
  occupancy: number;
  image_interval: number;
  max_loop_seconds: number;
  available_from: string;
  available_to: string;
  approval_status: NonNullable<InventoryItem["approvalStatus"]>;
  tags: unknown;
  display_template: string | null;
  display_language: string | null;
  comments_enabled: boolean;
  institution_id: string | null;
  owner_organization_id: string | null;
  delivery_mode: InventoryItem["deliveryMode"];
  product_type: string | null;
  production_lead_days: number;
  installation_lead_days: number;
  latitude: number | null;
  longitude: number | null;
  measurement_source: string | null;
  measurement_updated_at: string | null;
};

type OrganizationRow = { id: string; name: string; type: Organization["type"]; status: Organization["status"]; default_currency: "CAD"; timezone: string };
type MembershipRow = { organization_id: string; membership_role: MembershipRole };
type InventorySpecificationRow = {
  id: string; inventory_id: string; version: number; status: InventorySpecification["status"];
  trim_width_mm: number | null; trim_height_mm: number | null; visible_width_mm: number | null; visible_height_mm: number | null;
  bleed_mm: number | null; safe_area_mm: number | null; scale_ratio: string | null; minimum_dpi: number | null;
  colour_space: string | null; accepted_file_types: unknown; maximum_file_bytes: number | null; substrate: string | null;
  finishing: string | null; template_url: string | null; notes: string | null; created_at: string;
};

type BookingRow = {
  id: string;
  advertiser: string;
  inventory_id: string;
  campaign: string;
  start_date: string;
  end_date: string;
  ad_slots: number;
  creative_status: Booking["creativeStatus"];
  status: Booking["status"];
  spend: number;
  paid: boolean;
  pop: number;
  created_by: string | null;
  dayparts?: string[] | null;
};

type ApprovalEventRow = {
  id: string;
  booking_id: string;
  action: ApprovalEvent["action"];
  previous_status: Booking["status"];
  next_status: Booking["status"];
  created_at: string;
  campaign: string;
  inventory_id: string;
  actor_name: string;
};

type MediaRow = {
  starts_at: string|null; ends_at:string|null; revision:number;
  id: string;
  inventory_id: string;
  owner_id: string;
  title: string;
  original_name: string;
  mime_type: string;
  media_type: MediaResource["mediaType"];
  approval_status: MediaResource["approvalStatus"];
  size_bytes: number;
  storage_path: string;
  public_url: string;
  created_at: string;
};

type DeviceAlertRow = {
  id: string;
  institution_id: string;
  alert_type: DeviceAlertType;
  title: string;
  message: string;
  area: string;
  status: DeviceAlert["status"];
  target_device_ids: unknown;
  issued_by: string;
  created_by: string | null;
  created_at: string;
  expires_at: string;
  ended_at: string | null;
  image: DeviceAlert["image"];
  source?: string | null;
  official_alert_key?: string | null;
};

type TransactionRow = {
  id: string;
  booking_id: string;
  advertiser: string;
  amount: number;
  platform_fee: number;
  operator_payout: number;
  status: TransactionStatus;
  method: string;
  gateway_ref: string | null;
  created_at: string;
  paid_at: string | null;
};

type PopLogRow = {
  id: string;
  booking_id: string;
  inventory_id: string;
  plays: number;
  impressions: number;
  status: PopLog["status"];
  source: string;
  played_at: string;
};

type CreativeRow = {
  id: string;
  booking_id: string;
  source: Creative["source"];
  template: Creative["template"];
  format: Creative["format"];
  width: number;
  height: number;
  file_type: Creative["fileType"];
  file_size: number;
  safe_zone: number;
  distortion: number;
  original_name: string | null;
  mime_type: string | null;
  public_url: string | null;
  storage_path: string | null;
  status: Creative["status"];
  created_at: string;
};

type InventoryAdvertiserResourceRow = CreativeRow & {
  advertiser: string;
  campaign: string;
  start_date: string;
  end_date: string;
  booking_status: Booking["status"];
  dayparts?: string[] | null;
};

type PublicMediaRow = {
  original_name: string | null;
  mime_type: string | null;
  storage_path: string;
};

type InventoryCommentRow = {
  id: string;
  inventory_id: string;
  author_id: string | null;
  author_name: string;
  body: string;
  created_at: string;
};

export type DbUser = {
  screenScope?: string[]|null;
  id: string;
  name: string;
  email: string;
  role: Role;
  status: UserStatus;
  institutionId: string | null;
  operatorLimit: number;
  createdAt: string;
};

let pool: Pool | null = null;
let schemaReady: Promise<void> | null = null;

export function getDb() {
  return getPool();
}

function getPool() {
  if (!pool) {
    const connectionString = process.env.DATABASE_URL ?? process.env.POSTGRES_URL ?? "postgres://postgres:postgres@localhost:5432/ooh_market";
    pool = new Pool({
      connectionString,
      ssl: databaseSslConfig(),
      max: Number(process.env.DATABASE_POOL_SIZE ?? 10),
      connectionTimeoutMillis: Number(process.env.DATABASE_CONNECTION_TIMEOUT_MS ?? 10_000),
      idleTimeoutMillis: Number(process.env.DATABASE_IDLE_TIMEOUT_MS ?? 30_000),
    });
  }
  return pool;
}

async function ensureSchema() {
  if (!schemaReady) schemaReady = migrate();
  return schemaReady;
}

async function migrate() {
  const database = getPool();
  const schemaPath = path.join(process.cwd(), "database", "schema.sql");
  await database.query(readFileSync(schemaPath, "utf8"));
  await database.query("DELETE FROM sessions WHERE expires_at <= $1", [new Date().toISOString()]);
  await backfillInventoryTags();
}

export async function initializeDatabase() {
  await ensureSchema();
}

export async function checkDatabaseHealth() {
  await ensureSchema();
  await getPool().query("SELECT 1");
}

function databaseSslConfig() {
  if (process.env.DATABASE_SSL !== "true") return undefined;
  const rejectUnauthorized = process.env.DATABASE_SSL_REJECT_UNAUTHORIZED !== "false";
  const encodedCa = process.env.DATABASE_SSL_CA_BASE64;
  const textCa = process.env.DATABASE_SSL_CA;
  const ca = encodedCa
    ? Buffer.from(encodedCa, "base64").toString("utf8")
    : textCa?.replace(/\\n/g, "\n");
  return { rejectUnauthorized, ...(ca ? { ca } : {}) };
}

async function rows<T extends QueryResultRow>(sql: string, params: unknown[] = [], client?: PoolClient) {
  if (!client) await ensureSchema();
  const result = await (client ?? getPool()).query<T>(sql, params);
  return result.rows;
}

async function row<T extends QueryResultRow>(sql: string, params: unknown[] = [], client?: PoolClient) {
  const result = await rows<T>(sql, params, client);
  return result[0];
}

async function exec(sql: string, params: unknown[] = []) {
  await ensureSchema();
  return getPool().query(sql, params);
}

async function backfillInventoryTags() {
  const migrationKey = "inventory-tag-backfill";
  const migrationValue = "postgres-v1";
  const completed = await getPool().query<{ value: string }>("SELECT value FROM app_metadata WHERE key = $1", [migrationKey]);
  if (completed.rows[0]?.value === migrationValue) return;
  const result = await getPool().query<InventoryRow>("SELECT * FROM inventory");
  for (const entry of result.rows) {
    const item = mapInventory(entry);
    if (item.tags?.length) continue;
    await getPool().query("UPDATE inventory SET tags = $1::jsonb WHERE id = $2", [JSON.stringify(suggestedTagsForInventory(item)), item.id]);
  }
  await getPool().query(`
    INSERT INTO app_metadata (key, value) VALUES ($1, $2)
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value
  `, [migrationKey, migrationValue]);
}

export async function resetDatabaseForTests() {
  if (process.env.NODE_ENV !== "test") throw new Error("resetDatabaseForTests is only available during tests");
  await ensureSchema();
  await getPool().query(`
    TRUNCATE official_alert_matches, official_alerts, alert_ready_settings, alert_ready_feed, fleet_audit, fleet_announcements, player_alert_state, player_pairing_limits, idempotency_records, notifications, activity_events, placement_issues, digital_delivery_events, proof_records, work_order_evidence,
      installation_work_orders, production_jobs, creative_assignments, creative_reviews, creative_versions, creative_assets,
      design_requests, commercial_acceptances, quote_line_items, quotes, placements, campaigns, client_authorizations,
      brands, agency_clients, inventory_specifications, organization_memberships, inventory_comments, approval_events,
      creatives, pop_logs, transactions, device_alerts, media_resources, bookings, inventory, sessions, organizations, users, app_metadata
    RESTART IDENTITY CASCADE
  `);
}

export async function closeDb() {
  if (!pool) return;
  await pool.end();
  pool = null;
  schemaReady = null;
}

export async function listInventory() {
  return (await rows<InventoryRow>("SELECT * FROM inventory ORDER BY id")).map(mapInventory);
}

export async function listInventoryByInstitution(institutionId: string) {
  return (await rows<InventoryRow>("SELECT * FROM inventory WHERE institution_id = $1 ORDER BY id", [institutionId])).map(mapInventory);
}

export async function getInventory(id: string, client?: PoolClient) {
  const entry = await row<InventoryRow>("SELECT * FROM inventory WHERE id = $1", [id], client);
  return entry ? mapInventory(entry) : null;
}

export async function listOrganizationsForUser(userId: string) {
  const result = await rows<OrganizationRow & MembershipRow>(`
    SELECT organizations.*, organization_memberships.organization_id, organization_memberships.membership_role
    FROM organization_memberships JOIN organizations ON organizations.id = organization_memberships.organization_id
    WHERE organization_memberships.user_id = $1 AND organizations.status = 'active' ORDER BY lower(organizations.name)
  `, [userId]);
  return result.map((entry) => ({ organization: mapOrganization(entry), membershipRole: entry.membership_role }));
}

export async function getOrganizationMembership(userId: string, organizationId: string) {
  return row<MembershipRow>("SELECT organization_id, membership_role FROM organization_memberships WHERE user_id = $1 AND organization_id = $2", [userId, organizationId]);
}

export async function listInventorySpecifications(inventoryId: string) {
  return (await rows<InventorySpecificationRow>("SELECT * FROM inventory_specifications WHERE inventory_id = $1 ORDER BY version DESC", [inventoryId])).map(mapInventorySpecification);
}

export async function createInventorySpecification(inventoryId: string, specification: Omit<InventorySpecification, "id" | "inventoryId" | "version" | "status" | "createdAt">, userId: string) {
  const database = await getPool().connect();
  try {
    await database.query("BEGIN");
    await database.query("SELECT id FROM inventory WHERE id = $1 FOR UPDATE", [inventoryId]);
    const next = await database.query<{ version: number }>("SELECT COALESCE(MAX(version), 0) + 1 AS version FROM inventory_specifications WHERE inventory_id = $1", [inventoryId]);
    const version = Number(next.rows[0]?.version ?? 1);
    await database.query("UPDATE inventory_specifications SET status = 'retired' WHERE inventory_id = $1 AND status = 'active'", [inventoryId]);
    const id = `SPEC-${randomUUID().replace(/-/g, "").slice(0, 12).toUpperCase()}`;
    await database.query(`INSERT INTO inventory_specifications
      (id, inventory_id, version, status, trim_width_mm, trim_height_mm, visible_width_mm, visible_height_mm, bleed_mm, safe_area_mm, scale_ratio, minimum_dpi, colour_space, accepted_file_types, maximum_file_bytes, substrate, finishing, template_url, notes, created_by, created_at)
      VALUES ($1,$2,$3,'active',$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::jsonb,$14,$15,$16,$17,$18,$19,$20)`,
      [id, inventoryId, version, specification.trimWidthMm, specification.trimHeightMm, specification.visibleWidthMm, specification.visibleHeightMm, specification.bleedMm, specification.safeAreaMm, specification.scaleRatio, specification.minimumDpi, specification.colourSpace, JSON.stringify(specification.acceptedFileTypes), specification.maximumFileBytes, specification.substrate, specification.finishing, specification.templateUrl, specification.notes, userId, new Date().toISOString()]);
    await database.query("COMMIT");
    return mapInventorySpecification((await database.query<InventorySpecificationRow>("SELECT * FROM inventory_specifications WHERE id=$1", [id])).rows[0]);
  } catch (error) {
    await database.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally { database.release(); }
}

export async function listPublishedInventory() {
  return (await rows<InventoryRow>("SELECT * FROM inventory WHERE approval_status = 'approved' AND content_visibility='public' AND advertising_opt_in=TRUE ORDER BY id")).map(mapInventory);
}

// Loop time confirmed on a screen from `from` on, without advertiser names.
// The booking calendar reads it; the capacity check reads the same rows.
export async function listInventoryCommitments(inventoryId: string, from: string) {
  await ensureSchema();
  const client = await getPool().connect();
  try {
    return (await listDigitalCommitments(client, inventoryId))
      .filter((row) => row.end_date >= from)
      .map((row) => ({ start: row.start_date, end: row.end_date, seconds: row.seconds, dayparts: row.dayparts }));
  } finally {
    client.release();
  }
}

export async function getPublishedInventory(id: string, client?: PoolClient) {
  const entry = await row<InventoryRow>("SELECT * FROM inventory WHERE id = $1 AND approval_status = 'approved' AND content_visibility='public'", [id], client);
  return entry ? mapInventory(entry) : null;
}

export async function createInventory(item: InventoryItem, userId: string, institutionId: string | null = null) {
  const now = new Date().toISOString();
  const tags = normalizeTags(item.tags);
  const ownerUserId = institutionId ?? userId;
  const ownerOrganizationId = item.ownerOrganizationId ?? `ORG-${ownerUserId}`;
  await exec(`INSERT INTO organizations (id,name,type,status,created_at,updated_at)
    SELECT $1,name,CASE role WHEN 'advertiser' THEN 'advertiser' WHEN 'institutional' THEN 'institution' WHEN 'admin' THEN 'platform' ELSE 'media_owner' END,'active',$2,$2 FROM users WHERE id=$3
    ON CONFLICT(id) DO NOTHING`, [ownerOrganizationId,now,ownerUserId]);
  await exec(`INSERT INTO organization_memberships (organization_id,user_id,membership_role,created_at)
    SELECT $1,id,CASE role WHEN 'admin' THEN 'admin' WHEN 'operator' THEN 'operations' ELSE 'owner' END,$2 FROM users WHERE id=$3
    ON CONFLICT(organization_id,user_id) DO NOTHING`, [ownerOrganizationId,now,userId]);
  await exec(`
    INSERT INTO inventory
    (id, name, operator, format, x, y, address, price, impressions, traffic, income, audience, competitor, occupancy, image_interval, max_loop_seconds, available_from, available_to, approval_status, tags, display_template, comments_enabled, institution_id, created_by, created_at, updated_at, owner_organization_id, delivery_mode, product_type, production_lead_days, installation_lead_days, latitude, longitude, measurement_source, measurement_updated_at, display_language)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20::jsonb,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36)
  `, [item.id, item.name, item.operator, item.format, item.x, item.y, item.address, item.price, item.impressions, item.traffic, item.income, item.audience, item.competitor, item.occupancy, clampImageInterval(item.imageInterval), clampLoopCapacity(item.maxLoopSeconds), item.availableFrom, item.availableTo, item.approvalStatus ?? "approved", serializeTags(tags.length ? tags : suggestedTagsForInventory(item)), normalizeDisplayTemplate(item.displayTemplate), item.commentsEnabled !== false, institutionId, userId, now, now, ownerOrganizationId, item.deliveryMode ?? (item.format === "digital" ? "digital" : item.format === "static" ? "static" : "unknown"), item.productType ?? item.format, item.productionLeadDays ?? 0, item.installationLeadDays ?? 0, item.latitude ?? null, item.longitude ?? null, item.measurementSource ?? null, item.measurementUpdatedAt ?? null, normalizeDisplayLanguage(item.displayLanguage)]);
  await exec("UPDATE inventory SET advertising_opt_in=$1 WHERE id=$2",[item.advertisingOptIn??!institutionId,item.id]);
  return getInventory(item.id);
}

export async function updateInventoryRecord(id: string, updates: Partial<InventoryItem>, actor?:DbUser) {
  const current = await getInventory(id);
  if (!current) return null;
  const next = { ...current, ...updates };
  const database=await getPool().connect();
  try{await database.query("BEGIN");
  await database.query(`
    UPDATE inventory SET
      fleet_version=fleet_version+1, name = $1, operator = $2, format = $3, x = $4, y = $5, address = $6, price = $7, impressions = $8, traffic = $9, income = $10,
      audience = $11, competitor = $12, occupancy = $13, image_interval = $14, max_loop_seconds = $15, available_from = $16, available_to = $17,
      approval_status = $18, tags = $19::jsonb, display_template = $20, comments_enabled = $21, updated_at = $22,
      delivery_mode = $23, product_type = $24, production_lead_days = $25, installation_lead_days = $26,
      latitude = $27, longitude = $28, measurement_source = $29, measurement_updated_at = $30, display_language = $31
    WHERE id = $32
  `, [next.name, next.operator, next.format, next.x, next.y, next.address, next.price, next.impressions, next.traffic, next.income, next.audience, next.competitor, next.occupancy, clampImageInterval(next.imageInterval), clampLoopCapacity(next.maxLoopSeconds), next.availableFrom, next.availableTo, next.approvalStatus ?? "approved", serializeTags(next.tags), normalizeDisplayTemplate(next.displayTemplate), next.commentsEnabled !== false, new Date().toISOString(), next.deliveryMode ?? "unknown", next.productType ?? next.format, next.productionLeadDays ?? 0, next.installationLeadDays ?? 0, next.latitude ?? null, next.longitude ?? null, next.measurementSource ?? null, next.measurementUpdatedAt ?? null, normalizeDisplayLanguage(next.displayLanguage), id]);
  if(actor&&process.env.FEATURE_FLEET_OPERATIONS==="true")await database.query("INSERT INTO fleet_audit(id,actor_id,institution_id,target_id,action,revision,result) SELECT $1,$2,institution_id,id,'inventory_updated',fleet_version,'success' FROM inventory WHERE id=$3",[`AUD-${randomUUID()}`,actor.id,id]);
  await database.query("COMMIT");return await getInventory(id,database);
  }catch(e){await database.query("ROLLBACK");throw e;}finally{database.release();}
}

export async function deleteInventoryRecord(id: string) {
  await exec(`DELETE FROM campaigns WHERE id IN (
    SELECT campaigns.id FROM campaigns JOIN placements ON placements.campaign_id=campaigns.id
    WHERE campaigns.id LIKE 'CMP-LEGACY-%'
    GROUP BY campaigns.id HAVING BOOL_AND(placements.inventory_id=$1)
  )`, [id]);
  await exec("DELETE FROM inventory WHERE id = $1", [id]);
}

export async function listBookings() {
  return (await rows<BookingRow>("SELECT * FROM bookings ORDER BY created_at DESC, id DESC")).map(mapBooking);
}

export async function listBookingsCreatedBy(userId: string) {
  return (await rows<BookingRow>("SELECT * FROM bookings WHERE created_by = $1 ORDER BY created_at DESC, id DESC", [userId])).map(mapBooking);
}

export async function listBookingsForInstitution(institutionId: string) {
  return (await rows<BookingRow>(`
    SELECT bookings.* FROM bookings
    JOIN inventory ON inventory.id = bookings.inventory_id
    WHERE inventory.institution_id = $1
    ORDER BY bookings.created_at DESC, bookings.id DESC
  `, [institutionId])).map(mapBooking);
}

export async function createBookingRecord(booking: Booking, userId: string) {
  await ensureSchema();
  const database = await getPool().connect();
  try {
  await database.query("BEGIN");
  const unit=(await database.query<{image_interval:number;max_loop_seconds:number;delivery_mode:string}>("SELECT image_interval,max_loop_seconds,delivery_mode FROM inventory WHERE id=$1 FOR UPDATE",[booking.inventoryId])).rows[0];
  const dayparts = unit?.delivery_mode==="digital" ? bookingDayparts(booking.dayparts) : [];
  let snapshot = null;
  if(unit?.delivery_mode==="digital" && ["approved","scheduled","live"].includes(booking.status)) { snapshot=allocation(booking.start,booking.end,unit.image_interval,unit.max_loop_seconds,clampAdSlots(booking.adSlots),dayparts);await checkDigitalCapacity(database,booking.inventoryId,snapshot); }
  const now = new Date().toISOString();
  await database.query(`
    INSERT INTO bookings (id, advertiser, inventory_id, campaign, start_date, end_date, ad_slots, creative_status, status, spend, paid, pop, created_by, created_at, updated_at, dayparts)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
  `, [booking.id, booking.advertiser, booking.inventoryId, booking.campaign, booking.start, booking.end, clampAdSlots(booking.adSlots), booking.creativeStatus, booking.status, booking.spend, booking.paid, booking.pop, userId, now, now, dayparts]);
  await database.query(`INSERT INTO campaigns (id,organization_id,name,objective,geography,start_date,end_date,creative_path,status,created_by,created_at,updated_at)
    SELECT 'CMP-LEGACY-' || $1,'ORG-' || $2,$3,'Legacy booking compatibility',inventory.address,$4,$5,'upload',$6,$2,$7,$7 FROM inventory WHERE inventory.id=$8
    ON CONFLICT(id) DO NOTHING`, [booking.id,userId,booking.campaign,booking.start,booking.end,booking.status === "approved" ? "confirmed" : "planning",now,booking.inventoryId]);
  await database.query(`INSERT INTO placements (id,campaign_id,inventory_id,delivery_mode,start_date,end_date,status,estimated_media_cost,price_snapshot,created_at,updated_at)
    SELECT 'PLC-LEGACY-' || $1,'CMP-LEGACY-' || $1,inventory.id,inventory.delivery_mode,$2,$3,$4,$5,$6::jsonb,$7,$7 FROM inventory WHERE inventory.id=$8
    ON CONFLICT(id) DO NOTHING`, [booking.id,booking.start,booking.end,booking.status === "approved" ? "confirmed" : "requested",booking.spend,JSON.stringify({legacyBookingId:booking.id,amount:booking.spend,currency:"CAD",capturedAt:now}),now,booking.inventoryId]);
  if(snapshot){await database.query("UPDATE bookings SET schedule_snapshot=$2::jsonb WHERE id=$1",[booking.id,JSON.stringify(snapshot)]);await database.query("UPDATE placements SET schedule_snapshot=$2::jsonb WHERE id='PLC-LEGACY-' || $1",[booking.id,JSON.stringify(snapshot)]);}
  await database.query("COMMIT");
  return withDayparts({ ...booking, adSlots: clampAdSlots(booking.adSlots), createdBy: userId }, dayparts);
  } catch(error) { await database.query("ROLLBACK");throw error; } finally { database.release(); }
}

export async function createBookingWithCreativeRecord(
  booking: Booking,
  userId: string,
  creative: Omit<Creative, "createdAt"> & { storagePath: string },
) {
  await ensureSchema();
  const database = await getPool().connect();
  const createdAt = new Date().toISOString();
  const adSlots = clampAdSlots(booking.adSlots);
  try {
    await database.query("BEGIN");
    const unit=(await database.query<{image_interval:number;max_loop_seconds:number;delivery_mode:string}>("SELECT image_interval,max_loop_seconds,delivery_mode FROM inventory WHERE id=$1 FOR UPDATE",[booking.inventoryId])).rows[0];
    const dayparts = unit?.delivery_mode==="digital" ? bookingDayparts(booking.dayparts) : [];
    let snapshot=null;
    if(unit?.delivery_mode==="digital" && ["approved","scheduled","live"].includes(booking.status)){snapshot=allocation(booking.start,booking.end,unit.image_interval,unit.max_loop_seconds,adSlots,dayparts);await checkDigitalCapacity(database,booking.inventoryId,snapshot);}
    await database.query(`
      INSERT INTO bookings (id, advertiser, inventory_id, campaign, start_date, end_date, ad_slots, creative_status, status, spend, paid, pop, created_by, created_at, updated_at, dayparts)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
    `, [booking.id, booking.advertiser, booking.inventoryId, booking.campaign, booking.start, booking.end, adSlots, booking.creativeStatus, booking.status, booking.spend, booking.paid, booking.pop, userId, createdAt, createdAt, dayparts]);
    await database.query(`INSERT INTO campaigns (id,organization_id,name,objective,geography,start_date,end_date,creative_path,status,created_by,created_at,updated_at)
      SELECT 'CMP-LEGACY-' || $1,'ORG-' || $2,$3,'Legacy booking compatibility',inventory.address,$4,$5,'upload','planning',$2,$6,$6 FROM inventory WHERE inventory.id=$7
      ON CONFLICT(id) DO NOTHING`, [booking.id, userId, booking.campaign, booking.start, booking.end, createdAt, booking.inventoryId]);
    await database.query(`INSERT INTO placements (id,campaign_id,inventory_id,delivery_mode,start_date,end_date,status,estimated_media_cost,price_snapshot,created_at,updated_at)
      SELECT 'PLC-LEGACY-' || $1,'CMP-LEGACY-' || $1,inventory.id,inventory.delivery_mode,$2,$3,'requested',$4,$5::jsonb,$6,$6 FROM inventory WHERE inventory.id=$7
      ON CONFLICT(id) DO NOTHING`, [booking.id, booking.start, booking.end, booking.spend, JSON.stringify({ legacyBookingId: booking.id, amount: booking.spend, currency: "CAD", capturedAt: createdAt }), createdAt, booking.inventoryId]);
    await database.query(`
      INSERT INTO creatives (id, booking_id, source, template, format, width, height, file_type, file_size, safe_zone, distortion, original_name, mime_type, public_url, storage_path, status, created_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
    `, [creative.id, creative.bookingId, creative.source, creative.template, creative.format, creative.width, creative.height, creative.fileType, creative.fileSize, creative.safeZone, creative.distortion, creative.originalName, creative.mimeType, creative.publicUrl, creative.storagePath, creative.status, createdAt]);
    if(snapshot){await database.query("UPDATE bookings SET schedule_snapshot=$2::jsonb WHERE id=$1",[booking.id,JSON.stringify(snapshot)]);await database.query("UPDATE placements SET schedule_snapshot=$2::jsonb WHERE id='PLC-LEGACY-' || $1",[booking.id,JSON.stringify(snapshot)]);}
    await database.query("COMMIT");
    const { storagePath: _storagePath, ...storedCreative } = creative;
    return {
      booking: withDayparts({ ...booking, adSlots, createdBy: userId }, dayparts),
      creative: { ...storedCreative, createdAt } satisfies Creative,
    };
  } catch (error) {
    await database.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    database.release();
  }
}

export async function updateBookingRecord(id: string, updates: Partial<Booking>) {
  await ensureSchema();
  const database = await getPool().connect();
  try {
  await database.query("BEGIN");
  const locked = await database.query<BookingRow & {schedule_snapshot:import("./digital-schedule").Allocation|null}>("SELECT * FROM bookings WHERE id=$1 FOR UPDATE", [id]);
  const current = locked.rows[0] ? mapBooking(locked.rows[0]) : null;
  if (!current) { await database.query("COMMIT"); return null; }
  if (current.status === "cancelled") {
    if (updates.status !== "cancelled") throw new ScheduleError("Cancelled campaigns cannot be changed.");
    await database.query("COMMIT");
    return current;
  }
  if (updates.status === "cancelled" && (current.paid || !["pending approval", "creative review"].includes(current.status))) {
    throw new ScheduleError("Only unpaid pending campaigns can be cancelled.");
  }
  // Time-of-day slots belong to the request. Approval never changes them.
  const next: Booking = { ...current, ...updates, dayparts: current.dayparts };
  const unit = (await database.query<{image_interval:number;max_loop_seconds:number;delivery_mode:string}>("SELECT image_interval,max_loop_seconds,delivery_mode FROM inventory WHERE id=$1 FOR UPDATE", [next.inventoryId])).rows[0];
  if (unit?.delivery_mode === "digital" && ["approved", "scheduled", "live"].includes(next.status)) {
    const existing = locked.rows[0].schedule_snapshot;
    if(existing && (next.start!==existing.startDate || next.end!==existing.endDate || clampAdSlots(next.adSlots)!==existing.slots || next.inventoryId!==current.inventoryId))throw new ScheduleError("Confirmed digital allocation cannot be edited");
    const snapshot = existing ?? allocation(next.start,next.end,unit.image_interval,unit.max_loop_seconds,clampAdSlots(next.adSlots),bookingDayparts(next.dayparts));
    await checkDigitalCapacity(database,next.inventoryId,snapshot,[id]);
    await database.query("UPDATE bookings SET schedule_snapshot=$2::jsonb WHERE id=$1",[id,JSON.stringify(snapshot)]);
  }
  await database.query(`
    UPDATE bookings SET advertiser = $1, inventory_id = $2, campaign = $3, start_date = $4, end_date = $5, creative_status = $6,
      ad_slots = $7, status = $8, spend = $9, paid = $10, pop = $11, updated_at = $12
    WHERE id = $13
  `, [next.advertiser, next.inventoryId, next.campaign, next.start, next.end, next.creativeStatus, clampAdSlots(next.adSlots), next.status, next.spend, next.paid, next.pop, new Date().toISOString(), id]);
  const compatibilityStatus = next.status === "cancelled" ? "cancelled" : next.status === "approved" ? "confirmed" : "requested";
  await database.query("UPDATE campaigns SET name=$1,start_date=$2,end_date=$3,status=$4,version=version+1,updated_at=$5 WHERE id='CMP-LEGACY-' || $6", [next.campaign,next.start,next.end,next.status === "cancelled" ? "archived" : next.status === "approved" ? "confirmed" : "planning",new Date().toISOString(),id]);
  await database.query("UPDATE placements SET inventory_id=$1,start_date=$2,end_date=$3,status=$4,estimated_media_cost=$5,version=version+1,updated_at=$6 WHERE id='PLC-LEGACY-' || $7", [next.inventoryId,next.start,next.end,compatibilityStatus,next.spend,new Date().toISOString(),id]);
  await database.query("UPDATE placements SET schedule_snapshot=(SELECT schedule_snapshot FROM bookings WHERE id=$1) WHERE id='PLC-LEGACY-' || $1",[id]);
  await database.query("COMMIT");
  return withDayparts(next, current.dayparts);
  } catch(error) { await database.query("ROLLBACK"); throw error; } finally { database.release(); }
}

export async function getBooking(id: string) {
  const entry = await row<BookingRow>("SELECT * FROM bookings WHERE id = $1", [id]);
  return entry ? mapBooking(entry) : null;
}

export async function getBookingOwnerId(id: string) {
  const entry = await row<{ created_by: string | null }>("SELECT created_by FROM bookings WHERE id = $1", [id]);
  return entry?.created_by ?? null;
}

export async function createApprovalEvent(event: Omit<ApprovalEvent, "id" | "campaign" | "inventoryId" | "actorName" | "createdAt"> & { actorId: string }) {
  const id = `APR-${randomUUID().replace(/-/g, "").slice(0, 12).toUpperCase()}`;
  const createdAt = new Date().toISOString();
  await exec(`
    INSERT INTO approval_events (id, booking_id, actor_id, action, previous_status, next_status, created_at)
    VALUES ($1, $2, $3, $4, $5, $6, $7)
  `, [id, event.bookingId, event.actorId, event.action, event.previousStatus, event.nextStatus, createdAt]);
  return getApprovalEvent(id);
}

export async function listApprovalEvents(actorId?: string) {
  const base = `
    SELECT approval_events.*, bookings.campaign, bookings.inventory_id, users.name AS actor_name
    FROM approval_events
    JOIN bookings ON bookings.id = approval_events.booking_id
    JOIN users ON users.id = approval_events.actor_id
  `;
  const result = actorId
    ? await rows<ApprovalEventRow>(`${base} WHERE approval_events.actor_id = $1 ORDER BY approval_events.created_at DESC`, [actorId])
    : await rows<ApprovalEventRow>(`${base} ORDER BY approval_events.created_at DESC`);
  return result.map(mapApprovalEvent);
}

export async function listApprovalEventsForInstitution(institutionId: string) {
  return (await rows<ApprovalEventRow>(`
    SELECT approval_events.*, bookings.campaign, bookings.inventory_id, users.name AS actor_name
    FROM approval_events
    JOIN bookings ON bookings.id = approval_events.booking_id
    JOIN inventory ON inventory.id = bookings.inventory_id
    JOIN users ON users.id = approval_events.actor_id
    WHERE inventory.institution_id = $1
    ORDER BY approval_events.created_at DESC
  `, [institutionId])).map(mapApprovalEvent);
}

async function getApprovalEvent(id: string) {
  const entry = await row<ApprovalEventRow>(`
    SELECT approval_events.*, bookings.campaign, bookings.inventory_id, users.name AS actor_name
    FROM approval_events
    JOIN bookings ON bookings.id = approval_events.booking_id
    JOIN users ON users.id = approval_events.actor_id
    WHERE approval_events.id = $1
  `, [id]);
  return entry ? mapApprovalEvent(entry) : null;
}

export async function listPopLogs(bookingId?: string) {
  const result = bookingId
    ? await rows<PopLogRow>("SELECT * FROM pop_logs WHERE booking_id = $1 ORDER BY played_at DESC", [bookingId])
    : await rows<PopLogRow>("SELECT * FROM pop_logs ORDER BY played_at DESC");
  return result.map(mapPopLog);
}

export async function createPopLog(log: Omit<PopLog, "id">) {
  const id = `POP-${randomUUID().replace(/-/g, "").slice(0, 12).toUpperCase()}`;
  await exec(`
    INSERT INTO pop_logs (id, booking_id, inventory_id, plays, impressions, status, source, played_at)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
  `, [id, log.bookingId, log.inventoryId, log.plays, log.impressions, log.status, log.source, log.playedAt]);
  await recomputeBookingPop(log.bookingId);
  return { ...log, id } satisfies PopLog;
}

export async function recomputeBookingPop(bookingId: string) {
  const booking = await getBooking(bookingId);
  const inventory = booking ? await getInventory(booking.inventoryId) : null;
  if (!booking || !inventory) return null;
  const logs = await listPopLogs(bookingId);
  const verifiedPlays = logs.filter((log) => log.status === "verified").reduce((sum, log) => sum + log.plays, 0);
  const pop = Math.min(100, Math.round((verifiedPlays / Math.max(1, expectedPlays(booking.start, booking.end, booking.dayparts ?? []))) * 100));
  await exec("UPDATE bookings SET pop = $1, updated_at = $2 WHERE id = $3", [pop, new Date().toISOString(), bookingId]);
  return pop;
}

export async function listTransactions() {
  return (await rows<TransactionRow>("SELECT * FROM transactions ORDER BY created_at DESC")).map(mapTransaction);
}

export async function listTransactionsForInstitution(institutionId: string) {
  return (await rows<TransactionRow>(`
    SELECT transactions.* FROM transactions
    JOIN bookings ON bookings.id = transactions.booking_id
    JOIN inventory ON inventory.id = bookings.inventory_id
    WHERE inventory.institution_id = $1
    ORDER BY transactions.created_at DESC
  `, [institutionId])).map(mapTransaction);
}

export async function listTransactionsCreatedBy(userId: string) {
  return (await rows<TransactionRow>(`
    SELECT transactions.* FROM transactions
    JOIN bookings ON bookings.id = transactions.booking_id
    WHERE bookings.created_by = $1
    ORDER BY transactions.created_at DESC
  `, [userId])).map(mapTransaction);
}

export async function getTransactionByBooking(bookingId: string) {
  const entry = await row<TransactionRow>("SELECT * FROM transactions WHERE booking_id = $1", [bookingId]);
  return entry ? mapTransaction(entry) : null;
}

export async function ensureBookingTransactions() {
  const bookings = await listBookings();
  for (const booking of bookings) {
    if (await getTransactionByBooking(booking.id)) continue;
    const split = splitRevenue(booking.spend);
    await exec(`
      INSERT INTO transactions (id, booking_id, advertiser, amount, platform_fee, operator_payout, status, method, gateway_ref, created_at, paid_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      ON CONFLICT (booking_id) DO NOTHING
    `, [
      `TX-${booking.id.replace(/^BK-/, "")}`,
      booking.id,
      booking.advertiser,
      split.gross,
      split.platformFee,
      split.operatorPayout,
      booking.paid ? "paid" : "pending",
      booking.paid ? "card" : "unpaid",
      null,
      new Date().toISOString(),
      booking.paid ? new Date().toISOString() : null,
    ]);
  }
}

export async function upsertTransaction(transaction: Transaction) {
  await exec(`
    INSERT INTO transactions (id, booking_id, advertiser, amount, platform_fee, operator_payout, status, method, gateway_ref, created_at, paid_at)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
    ON CONFLICT (booking_id) DO UPDATE SET
      advertiser = EXCLUDED.advertiser,
      amount = EXCLUDED.amount,
      platform_fee = EXCLUDED.platform_fee,
      operator_payout = EXCLUDED.operator_payout,
      status = EXCLUDED.status,
      method = EXCLUDED.method,
      gateway_ref = EXCLUDED.gateway_ref,
      paid_at = EXCLUDED.paid_at
  `, [transaction.id, transaction.bookingId, transaction.advertiser, transaction.amount, transaction.platformFee, transaction.operatorPayout, transaction.status, transaction.method, transaction.gatewayRef, transaction.createdAt, transaction.paidAt]);
  return getTransactionByBooking(transaction.bookingId);
}

export async function listCreatives(bookingId?: string) {
  const result = bookingId
    ? await rows<CreativeRow>("SELECT * FROM creatives WHERE booking_id = $1 ORDER BY created_at DESC", [bookingId])
    : await rows<CreativeRow>("SELECT * FROM creatives ORDER BY created_at DESC");
  return result.map(mapCreative);
}

export async function updatePendingCreativeStatuses(bookingId: string, status: Extract<Creative["status"], "approved" | "needs changes">) {
  await exec("UPDATE creatives SET status = $1 WHERE booking_id = $2 AND status = 'pending review'", [status, bookingId]);
  return listCreatives(bookingId);
}

export async function createCreative(creative: Omit<Creative, "id" | "createdAt"> & { id?: string; storagePath?: string | null }) {
  const id = creative.id ?? `CRV-${randomUUID().replace(/-/g, "").slice(0, 12).toUpperCase()}`;
  const createdAt = new Date().toISOString();
  await exec(`
    INSERT INTO creatives (id, booking_id, source, template, format, width, height, file_type, file_size, safe_zone, distortion, original_name, mime_type, public_url, storage_path, status, created_at)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
  `, [id, creative.bookingId, creative.source, creative.template, creative.format, creative.width, creative.height, creative.fileType, creative.fileSize, creative.safeZone, creative.distortion, creative.originalName, creative.mimeType, creative.publicUrl, creative.storagePath ?? null, creative.status, createdAt]);
  const { storagePath: _storagePath, ...storedCreative } = creative;
  return { ...storedCreative, id, createdAt } satisfies Creative;
}

export async function getPublicMediaResource(id: string) {
  const media = await row<PublicMediaRow>(`
    SELECT media_resources.original_name, media_resources.mime_type, media_resources.storage_path
    FROM media_resources
    JOIN inventory ON inventory.id = media_resources.inventory_id
    WHERE media_resources.id = $1
      AND media_resources.approval_status = 'approved'
      AND inventory.approval_status = 'approved' AND inventory.content_visibility='public'
      AND (media_resources.starts_at IS NULL OR media_resources.starts_at::timestamptz <= NOW()) AND (media_resources.ends_at IS NULL OR media_resources.ends_at::timestamptz > NOW())
  `, [id]);
  if (media) return {
    originalName: media.original_name ?? "media-resource",
    mimeType: media.mime_type ?? "application/octet-stream",
    storagePath: media.storage_path,
    cacheable: false,
  };

  const creative = await row<PublicMediaRow>(`
    SELECT creatives.original_name, creatives.mime_type, creatives.storage_path
    FROM creatives
    JOIN bookings ON bookings.id = creatives.booking_id JOIN inventory private_guard ON private_guard.id=bookings.inventory_id
    WHERE private_guard.content_visibility='public' AND creatives.id = $1
      AND creatives.source IN ('upload', 'template')
      AND creatives.status = 'approved'
      AND creatives.storage_path IS NOT NULL
      AND bookings.status IN ('approved', 'scheduled', 'live')
      AND bookings.start_date <= CURRENT_DATE::text
      AND bookings.end_date >= CURRENT_DATE::text
  `, [id]);
  return creative ? {
    originalName: creative.original_name ?? "uploaded-creative",
    mimeType: creative.mime_type ?? "application/octet-stream",
    storagePath: creative.storage_path,
    cacheable: false,
  } : null;
}

export async function getCreativeStoredMedia(id: string) {
  return row<{ booking_id: string; original_name: string | null; mime_type: string | null; storage_path: string }>(`
    SELECT booking_id, original_name, mime_type, storage_path FROM creatives
    WHERE id = $1 AND storage_path IS NOT NULL
  `, [id]);
}

export async function getLegacyTemplateCreative(id: string) {
  return row<{
    booking_id: string;
    template: Creative["template"];
    creative_status: Creative["status"];
    booking_status: Booking["status"];
    start_date: string;
    end_date: string;
    content_visibility: string;
    today: string;
  }>(`
    SELECT creatives.booking_id, creatives.template, creatives.status AS creative_status,
      bookings.status AS booking_status, bookings.start_date, bookings.end_date,
      inventory.content_visibility, CURRENT_DATE::text AS today
    FROM creatives JOIN bookings ON bookings.id = creatives.booking_id
      JOIN inventory ON inventory.id = bookings.inventory_id
    WHERE creatives.id = $1 AND creatives.source = 'template' AND creatives.storage_path IS NULL
  `, [id]);
}

// A time-of-day booking runs on Toronto dates. asOf is a UTC date, which is
// already tomorrow after 8 p.m. in Toronto, so those bookings are read from one
// day earlier and the caller applies the exact local rule.
export async function listInventoryAdvertiserResources(inventoryId: string, asOf = new Date().toISOString().slice(0, 10), client?: PoolClient, through = asOf) {
  const result = await rows<InventoryAdvertiserResourceRow>(`
    SELECT
      creatives.*,
      bookings.advertiser,
      bookings.campaign,
      bookings.start_date,
      bookings.end_date,
      bookings.status AS booking_status,
      bookings.dayparts
    FROM creatives
    JOIN bookings ON bookings.id = creatives.booking_id
    WHERE bookings.inventory_id = $1
      AND creatives.source IN ('upload', 'template')
      AND creatives.status = 'approved'
      AND (creatives.public_url IS NOT NULL OR creatives.source = 'template')
      AND bookings.status IN ('approved', 'scheduled', 'live')
      AND bookings.start_date <= $3
      AND (bookings.end_date >= $2 OR (cardinality(bookings.dayparts) > 0 AND bookings.end_date >= $4))
    ORDER BY creatives.created_at DESC
  `, [inventoryId, asOf, through, addDays(asOf, -1)], client);

  return result.map((entry) => ({
    ...mapCreative(entry),
    advertiser: entry.advertiser,
    campaign: entry.campaign,
    start: entry.start_date,
    end: entry.end_date,
    bookingStatus: entry.booking_status,
    ...(bookingDayparts(entry.dayparts).length ? { dayparts: bookingDayparts(entry.dayparts) } : {}),
  } satisfies InventoryAdvertiserResource));
}

export async function listMediaResources(inventoryId?: string, client?: PoolClient) {
  const result = inventoryId
    ? await rows<MediaRow>("SELECT * FROM media_resources WHERE inventory_id = $1 ORDER BY created_at DESC", [inventoryId], client)
    : await rows<MediaRow>("SELECT * FROM media_resources ORDER BY created_at DESC", [], client);
  return result.map(mapMedia);
}

export async function listMediaResourcesForInstitution(institutionId: string) {
  return (await rows<MediaRow>(`
    SELECT media_resources.* FROM media_resources
    JOIN inventory ON inventory.id = media_resources.inventory_id
    WHERE inventory.institution_id = $1
    ORDER BY media_resources.created_at DESC
  `, [institutionId])).map(mapMedia);
}

export async function getMediaResource(id: string) {
  const entry = await row<MediaRow>("SELECT * FROM media_resources WHERE id = $1", [id]);
  return entry ? { resource: mapMedia(entry), storagePath: entry.storage_path } : null;
}

export async function deleteMediaResource(id: string) {
  const current = await getMediaResource(id);
  if (!current) return null;
  await exec("DELETE FROM media_resources WHERE id = $1", [id]);
  return current;
}

export async function createMediaResource(resource: MediaResource & { storagePath: string }) {
  await ensureSchema();
  const database=await getPool().connect();
  try{await database.query("BEGIN");
  await database.query("SELECT id FROM inventory WHERE id=$1 FOR SHARE",[resource.inventoryId]);
  await database.query(`
    INSERT INTO media_resources
    (id, inventory_id, owner_id, title, original_name, mime_type, media_type, approval_status, size_bytes, storage_path, public_url, created_at)
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
  `, [resource.id, resource.inventoryId, resource.ownerId, resource.title, resource.originalName, resource.mimeType, resource.mediaType, resource.approvalStatus, resource.sizeBytes, resource.storagePath, resource.publicUrl, resource.createdAt]);
  if(process.env.FEATURE_FLEET_OPERATIONS==="true")await database.query("INSERT INTO fleet_audit(id,actor_id,institution_id,target_id,action,revision,result) SELECT $1,$2,institution_id,id,'media_uploaded',1,'success' FROM inventory WHERE id=$3",[`AUD-${randomUUID()}`,resource.ownerId,resource.inventoryId]);
  await database.query("COMMIT");return resource;
  }catch(e){await database.query("ROLLBACK");throw e;}finally{database.release();}
}

export async function updateMediaApprovalStatus(id:string,approvalStatus:MediaResource["approvalStatus"],actorId?:string){
 await ensureSchema();const database=await getPool().connect();try{await database.query("BEGIN");const result=await database.query<MediaRow>("UPDATE media_resources SET approval_status=$1,revision=revision+1 WHERE id=$2 RETURNING *",[approvalStatus,id]);const media=result.rows[0];
 if(media&&actorId&&process.env.FEATURE_FLEET_OPERATIONS==="true")await database.query("INSERT INTO fleet_audit(id,actor_id,institution_id,target_id,resource_id,action,revision,result) SELECT $1,$2,institution_id,id,$3,$4,$5,'success' FROM inventory WHERE id=$6",[`AUD-${randomUUID()}`,actorId,id,`media_${approvalStatus}`,media.revision,media.inventory_id]);
 await database.query("COMMIT");return media?mapMedia(media):null;
 }catch(e){await database.query("ROLLBACK");throw e;}finally{database.release();}
}

export async function listDeviceAlerts(institutionId?: string, asOf = new Date().toISOString()) {
  const scopeClause = institutionId ? "WHERE institution_id = $1" : "";
  const asOfParameter = institutionId ? "$2" : "$1";
  const result = await rows<DeviceAlertRow>(`
    WITH scoped AS (
      SELECT * FROM device_alerts ${scopeClause}
    ), recent AS (
      SELECT * FROM scoped ORDER BY created_at DESC LIMIT 100
    ), active AS (
      SELECT * FROM scoped WHERE status = 'active' AND expires_at > ${asOfParameter}
    )
    SELECT * FROM (
      SELECT * FROM active
      UNION
      SELECT * FROM recent
    ) selected
    ORDER BY created_at DESC
  `, institutionId ? [institutionId, asOf] : [asOf]);
  return result.map(mapDeviceAlert);
}

export async function getDeviceAlert(id: string) {
  const entry = await row<DeviceAlertRow>("SELECT * FROM device_alerts WHERE id = $1", [id]);
  return entry ? mapDeviceAlert(entry) : null;
}

export async function getActiveDeviceAlertForDevice(deviceId: string, asOf = new Date().toISOString(), client?: PoolClient) {
  const entry = await row<DeviceAlertRow>(`
    SELECT * FROM device_alerts
    WHERE status = 'active'
      AND expires_at > $1
      AND target_device_ids ? $2
    ORDER BY created_at DESC
    LIMIT 1
  `, [asOf, deviceId], client);
  return entry ? mapDeviceAlert(entry) : null;
}

export async function createDeviceAlert(alert: Omit<DeviceAlert, "id" | "status" | "createdAt" | "endedAt">) {
  const created = materializeDeviceAlert(alert);
  await exec(deviceAlertInsertSql, [...deviceAlertInsertParams(created), null]);
  return created;
}

export class DeviceAlertTargetError extends Error {}

export async function createDeviceAlertIfNoConflict(alert: Omit<DeviceAlert, "id" | "status" | "createdAt" | "endedAt">, imageStoragePath?: string) {
  await ensureSchema();
  const database = await getPool().connect();
  const created = materializeDeviceAlert(alert);

  try {
    await database.query("BEGIN");
    await database.query("SELECT pg_advisory_xact_lock(hashtext('device-alert'), hashtext($1))", [alert.institutionId]);
    const targets = await database.query<InventoryRow>(
      "SELECT * FROM inventory WHERE id=ANY($1::text[]) ORDER BY id FOR UPDATE", [alert.targetDeviceIds],
    );
    if (targets.rows.length !== new Set(alert.targetDeviceIds).size || targets.rows.some(target =>
      target.institution_id !== alert.institutionId || target.approval_status !== "approved" ||
      !isDigitalInventory({ format: target.format, deliveryMode: target.delivery_mode ?? undefined })
    )) {
      throw new DeviceAlertTargetError("Selected screens changed. Find screens again and review the targets before publishing.");
    }
    const conflict = await database.query<DeviceAlertRow>(`
      SELECT * FROM device_alerts
      WHERE institution_id = $1
        AND status = 'active'
        AND expires_at > $2
        AND target_device_ids ?| $3::text[]
      ORDER BY created_at DESC
      LIMIT 1
    `, [alert.institutionId, created.createdAt, alert.targetDeviceIds]);

    if (conflict.rows[0]) {
      await database.query("ROLLBACK");
      return { alert: null, conflictingAlert: mapDeviceAlert(conflict.rows[0]) };
    }

    await database.query(deviceAlertInsertSql, [...deviceAlertInsertParams(created), imageStoragePath ?? null]);
    if(process.env.FEATURE_FLEET_OPERATIONS==="true")for(const target of created.targetDeviceIds)await database.query("INSERT INTO fleet_audit(id,actor_id,institution_id,target_id,resource_id,target_scope,action,revision,result,priority) VALUES($1,$2,$3,$4,$5,$6::jsonb,'alert_created',1,'success','emergency')",[`AUD-${randomUUID()}`,created.createdBy,created.institutionId,target,created.id,JSON.stringify(created.targetDeviceIds)]);
    await database.query("COMMIT");
    return { alert: created, conflictingAlert: null };
  } catch (error) {
    await database.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    database.release();
  }
}

export async function endDeviceAlert(id:string,actorId?:string){
 await ensureSchema();const database=await getPool().connect();try{await database.query("BEGIN");const result=await database.query<DeviceAlertRow>("UPDATE device_alerts SET status='ended',ended_at=$1 WHERE id=$2 AND status='active' RETURNING *",[new Date().toISOString(),id]);const alert=result.rows[0]?mapDeviceAlert(result.rows[0]):null;
 if(alert&&actorId&&process.env.FEATURE_FLEET_OPERATIONS==="true")for(const target of alert.targetDeviceIds)await database.query("INSERT INTO fleet_audit(id,actor_id,institution_id,target_id,resource_id,target_scope,action,revision,result,priority) VALUES($1,$2,$3,$4,$5,$6::jsonb,'alert_ended',1,'success','emergency')",[`AUD-${randomUUID()}`,actorId,alert.institutionId,target,id,JSON.stringify(alert.targetDeviceIds)]);
 await database.query("COMMIT");return alert;
 }catch(e){await database.query("ROLLBACK");throw e;}finally{database.release();}
}

export async function getUserByEmail(email: string) {
  return row<UserRow>("SELECT * FROM users WHERE email = $1", [email.toLowerCase()]);
}

export async function countUsers() {
  const entry = await row<{ count: string }>("SELECT COUNT(*) AS count FROM users");
  return Number(entry?.count ?? 0);
}

export async function getUserById(id: string) {
  const entry = await row<UserRow>("SELECT * FROM users WHERE id = $1", [id]);
  return entry ? mapUser(entry) : null;
}

export async function createUser(name: string, email: string, passwordHash: string, role: Role, options: { institutionId?: string | null; operatorLimit?: number } = {}) {
  const entry = {
    id: `USR-${Date.now().toString(36).toUpperCase()}`,
    name,
    email: email.toLowerCase(),
    password_hash: passwordHash,
    role,
    status: "active" as const,
    institution_id: role === "operator" ? options.institutionId ?? null : null,
    operator_limit: role === "institutional" ? clampOperatorLimit(options.operatorLimit) : 0,
    created_at: new Date().toISOString(),
  };
  await exec("INSERT INTO users (id, name, email, password_hash, role, status, institution_id, operator_limit, created_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)",
    [entry.id, entry.name, entry.email, entry.password_hash, entry.role, entry.status, entry.institution_id, entry.operator_limit, entry.created_at]);
  const organizationId = role === "operator" && entry.institution_id ? `ORG-${entry.institution_id}` : `ORG-${entry.id}`;
  if (!(role === "operator" && entry.institution_id)) {
    const organizationType = role === "advertiser" ? "advertiser" : role === "institutional" ? "institution" : role === "admin" ? "platform" : "media_owner";
    await exec("INSERT INTO organizations (id, name, type, status, created_at, updated_at) VALUES ($1,$2,$3,'active',$4,$4) ON CONFLICT (id) DO NOTHING", [organizationId, name, organizationType, entry.created_at]);
  }
  await exec("INSERT INTO organization_memberships (organization_id, user_id, membership_role, created_at) VALUES ($1,$2,$3,$4) ON CONFLICT (organization_id, user_id) DO NOTHING", [organizationId, entry.id, role === "operator" ? "operations" : role === "admin" ? "admin" : "owner", entry.created_at]);
  return mapUser(entry);
}

export async function listNonAdminUsers() {
  return (await rows<UserRow>("SELECT * FROM users WHERE role != 'admin' ORDER BY created_at DESC, lower(name)")).map(mapUser);
}

export async function listInstitutionOperators(institutionId: string) {
  return (await rows<UserRow>("SELECT * FROM users WHERE role = 'operator' AND status='active' AND institution_id = $1 ORDER BY created_at DESC, lower(name)", [institutionId])).map(mapUser);
}

export async function countInstitutionOperators(institutionId: string) {
  const entry = await row<{ count: string }>("SELECT COUNT(*) AS count FROM users WHERE role = 'operator' AND status='active' AND institution_id = $1", [institutionId]);
  return Number(entry?.count ?? 0);
}

export async function updateManagedUser(id: string, updates: { role?: Exclude<Role, "admin">; status?: UserStatus; institutionId?: string | null; operatorLimit?: number }) {
  const current = await getUserById(id);
  if (!current || current.role === "admin") return null;
  const role = updates.role ?? current.role;
  const status = updates.status ?? current.status;
  const institutionId = role === "operator" ? updates.institutionId ?? current.institutionId : null;
  const operatorLimit = role === "institutional" ? clampOperatorLimit(updates.operatorLimit ?? current.operatorLimit) : 0;
  if (role === "operator" && !institutionId) return null;
  if (current.role === "institutional" && role !== "institutional" && await countInstitutionOperators(current.id) > 0) return null;
  if (role === "institutional" && operatorLimit < await countInstitutionOperators(current.id)) return null;
  await exec("UPDATE users SET role = $1, status = $2, institution_id = $3, operator_limit = $4 WHERE id = $5", [role, status, institutionId, operatorLimit, id]);
  if (status === "banned" || role!==current.role || institutionId!==current.institutionId) await deleteSessionsForUser(id);
  return getUserById(id);
}

export async function deleteManagedUser(id: string) {
  const current = await getUserById(id);
  if (!current || current.role === "admin") return false;
  if (current.role === "institutional") await exec("DELETE FROM users WHERE institution_id = $1", [id]);
  await exec("DELETE FROM users WHERE id = $1", [id]);
  return true;
}

export async function createSessionRecord(token: string, userId: string, expiresAt: string) {
  await exec("INSERT INTO sessions (token, user_id, expires_at, created_at) VALUES ($1, $2, $3, $4)", [hashSessionToken(token), userId, expiresAt, new Date().toISOString()]);
}

export async function getUserBySession(token: string) {
  const entry = await row<UserRow>(`
    SELECT users.* FROM sessions
    JOIN users ON users.id = sessions.user_id
    WHERE sessions.token = $1 AND sessions.expires_at > $2
  `, [hashSessionToken(token), new Date().toISOString()]);
  return entry ? mapUser(entry) : null;
}

export async function deleteSessionRecord(token: string) {
  await exec("DELETE FROM sessions WHERE token = $1", [hashSessionToken(token)]);
}

export async function deleteSessionsForUser(userId: string) {
  await exec("DELETE FROM sessions WHERE user_id = $1", [userId]);
}

export async function listInventoryComments(inventoryId: string) {
  return (await rows<InventoryCommentRow>("SELECT * FROM inventory_comments WHERE inventory_id = $1 ORDER BY created_at ASC", [inventoryId])).map(mapInventoryComment);
}

export async function createInventoryComment(comment: Omit<InventoryComment, "id" | "createdAt">) {
  const id = `CMT-${randomUUID().replace(/-/g, "").slice(0, 12).toUpperCase()}`;
  const createdAt = new Date().toISOString();
  await exec("INSERT INTO inventory_comments (id, inventory_id, author_id, author_name, body, created_at) VALUES ($1, $2, $3, $4, $5, $6)",
    [id, comment.inventoryId, comment.authorId, comment.authorName, comment.body, createdAt]);
  return { ...comment, id, createdAt } satisfies InventoryComment;
}

function hashSessionToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function clampOperatorLimit(value: unknown) {
  const parsed = Number(value);
  return Math.min(100, Math.max(1, Math.round(Number.isFinite(parsed) ? parsed : 5)));
}

function normalizeDisplayTemplate(value: unknown): DisplayTemplate {
  return typeof value === "string" && (displayTemplates as string[]).includes(value) ? (value as DisplayTemplate) : "fullscreen";
}

function normalizeDisplayLanguage(value: unknown): Locale {
  return isLocale(value) ? value : "en";
}

function mapInventoryComment(entry: InventoryCommentRow): InventoryComment {
  return {
    id: entry.id,
    inventoryId: entry.inventory_id,
    authorId: entry.author_id,
    authorName: entry.author_name,
    body: entry.body,
    createdAt: stringifyDate(entry.created_at),
  };
}

function mapInventory(entry: InventoryRow): InventoryItem {
  return {
    building:entry.building,department:entry.department,contentVisibility:entry.content_visibility,advertisingOptIn:entry.advertising_opt_in,restrictedCategories:entry.restricted_categories,reservedSeconds:entry.reserved_seconds,fleetVersion:entry.fleet_version,
    id: entry.id,
    name: entry.name,
    operator: entry.operator,
    format: entry.format,
    x: Number(entry.x),
    y: Number(entry.y),
    address: entry.address,
    price: Number(entry.price),
    impressions: Number(entry.impressions),
    traffic: Number(entry.traffic),
    income: Number(entry.income),
    audience: entry.audience,
    competitor: entry.competitor,
    occupancy: Number(entry.occupancy),
    imageInterval: clampImageInterval(Number(entry.image_interval ?? 6)),
    maxLoopSeconds: clampLoopCapacity(Number(entry.max_loop_seconds ?? 120)),
    availableFrom: entry.available_from,
    availableTo: entry.available_to,
    approvalStatus: entry.approval_status ?? "approved",
    tags: parseTags(entry.tags),
    displayTemplate: normalizeDisplayTemplate(entry.display_template),
    displayLanguage: normalizeDisplayLanguage(entry.display_language),
    commentsEnabled: entry.comments_enabled !== false,
    institutionId: entry.institution_id ?? null,
    ownerOrganizationId: entry.owner_organization_id ?? null,
    deliveryMode: entry.delivery_mode ?? "unknown",
    productType: entry.product_type ?? entry.format,
    productionLeadDays: Number(entry.production_lead_days ?? 0),
    installationLeadDays: Number(entry.installation_lead_days ?? 0),
    latitude: entry.latitude == null ? null : Number(entry.latitude),
    longitude: entry.longitude == null ? null : Number(entry.longitude),
    measurementSource: entry.measurement_source ?? null,
    measurementUpdatedAt: entry.measurement_updated_at ? stringifyDate(entry.measurement_updated_at) : null,
  };
}

function mapOrganization(entry: OrganizationRow): Organization {
  return { id: entry.id, name: entry.name, type: entry.type, status: entry.status, defaultCurrency: entry.default_currency, timezone: entry.timezone };
}

function mapInventorySpecification(entry: InventorySpecificationRow): InventorySpecification {
  return {
    id: entry.id, inventoryId: entry.inventory_id, version: Number(entry.version), status: entry.status,
    trimWidthMm: numberOrNull(entry.trim_width_mm), trimHeightMm: numberOrNull(entry.trim_height_mm),
    visibleWidthMm: numberOrNull(entry.visible_width_mm), visibleHeightMm: numberOrNull(entry.visible_height_mm),
    bleedMm: numberOrNull(entry.bleed_mm), safeAreaMm: numberOrNull(entry.safe_area_mm), scaleRatio: entry.scale_ratio,
    minimumDpi: numberOrNull(entry.minimum_dpi), colourSpace: entry.colour_space, acceptedFileTypes: parseStringArray(entry.accepted_file_types),
    maximumFileBytes: numberOrNull(entry.maximum_file_bytes), substrate: entry.substrate, finishing: entry.finishing,
    templateUrl: entry.template_url, notes: entry.notes, createdAt: stringifyDate(entry.created_at),
  };
}

function numberOrNull(value: unknown) { return value == null ? null : Number(value); }

function serializeTags(value: unknown) {
  return JSON.stringify(normalizeTags(value));
}

function parseTags(value: unknown) {
  if (Array.isArray(value)) return normalizeTags(value);
  if (typeof value === "string") {
    try {
      return normalizeTags(JSON.parse(value));
    } catch {
      return [];
    }
  }
  return [];
}

function normalizeTags(value: unknown) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value
    .filter((tag): tag is string => typeof tag === "string")
    .map((tag) => tag.trim().toLowerCase().replace(/\s+/g, "-"))
    .filter(Boolean)
    .map((tag) => tag.slice(0, 40)))]
    .slice(0, 30);
}

function suggestedTagsForInventory(item: InventoryItem) {
  const audience = item.audience.toLowerCase();
  const context = `${item.name} ${item.address} ${item.operator}`.toLowerCase();
  const tags = [
    item.format === "digital" ? "digital" : "physical",
    item.impressions >= 130000 ? "large" : item.impressions >= 70000 ? "medium" : "small",
    item.income >= 110000 ? "high-income" : item.income >= 75000 ? "medium-income" : "low-income",
    item.format === "transit" ? "near-transit" : "commercial",
    audience.includes("student") ? "18-24" : audience.includes("professional") ? "35-49" : "25-34",
    audience.includes("student") ? "near-university" : "urban",
    audience.includes("commuter") ? "near-major-highway" : "private",
  ];
  if (context.includes("university")) tags.push("near-university");
  if (context.includes("airport") || context.includes("tourism")) tags.push("tourism");
  if (context.includes("retail") || context.includes("mall")) tags.push("retail");
  if (context.includes("arena") || context.includes("stadium")) tags.push("sports");
  return normalizeTags(tags);
}

function clampImageInterval(value: number) {
  return Math.min(60, Math.max(2, Math.round(Number.isFinite(value) ? value : 6)));
}

function clampLoopCapacity(value: number) {
  return Math.min(3600, Math.max(2, Math.round(Number.isFinite(value) ? value : 120)));
}

function clampAdSlots(value: number) {
  return Math.min(100, Math.max(1, Math.round(Number.isFinite(value) ? value : 1)));
}

function mapBooking(entry: BookingRow): Booking {
  return {
    id: entry.id,
    advertiser: entry.advertiser,
    inventoryId: entry.inventory_id,
    campaign: entry.campaign,
    start: entry.start_date,
    end: entry.end_date,
    adSlots: clampAdSlots(Number(entry.ad_slots ?? 1)),
    creativeStatus: entry.creative_status,
    status: entry.status,
    spend: Number(entry.spend),
    paid: Boolean(entry.paid),
    pop: Number(entry.pop),
    createdBy: entry.created_by ?? undefined,
    // Only a booking with chosen slots carries the field. All day is the default.
    ...(bookingDayparts(entry.dayparts).length ? { dayparts: bookingDayparts(entry.dayparts) } : {}),
  };
}

function withDayparts(booking: Booking, dayparts: Booking["dayparts"] = []): Booking {
  const { dayparts: _requested, ...rest } = booking;
  return dayparts.length ? { ...rest, dayparts } : rest;
}

function bookingDayparts(value: unknown) {
  return parseDayparts(value) ?? [];
}

function mapApprovalEvent(entry: ApprovalEventRow): ApprovalEvent {
  return {
    id: entry.id,
    bookingId: entry.booking_id,
    campaign: entry.campaign,
    inventoryId: entry.inventory_id,
    action: entry.action,
    previousStatus: entry.previous_status,
    nextStatus: entry.next_status,
    actorName: entry.actor_name,
    createdAt: stringifyDate(entry.created_at),
  };
}

function mapMedia(entry: MediaRow): MediaResource {
  return {
    startsAt:entry.starts_at,endsAt:entry.ends_at,revision:entry.revision,
    id: entry.id,
    inventoryId: entry.inventory_id,
    ownerId: entry.owner_id,
    title: entry.title,
    originalName: entry.original_name,
    mimeType: entry.mime_type,
    mediaType: entry.media_type,
    approvalStatus: entry.approval_status,
    sizeBytes: Number(entry.size_bytes),
    publicUrl: entry.public_url,
    createdAt: stringifyDate(entry.created_at),
  };
}

function mapDeviceAlert(entry: DeviceAlertRow): DeviceAlert {
  return {
    id: entry.id,
    institutionId: entry.institution_id,
    alertType: entry.alert_type,
    title: entry.title,
    message: entry.message,
    area: entry.area,
    status: entry.status,
    targetDeviceIds: parseStringArray(entry.target_device_ids),
    issuedBy: entry.issued_by,
    createdBy: entry.created_by,
    createdAt: stringifyDate(entry.created_at),
    expiresAt: stringifyDate(entry.expires_at),
    endedAt: entry.ended_at ? stringifyDate(entry.ended_at) : null,
    image: entry.image ?? null,
    // Only a relayed official alert carries the fields; institution overrides stay as they were.
    ...(entry.source === "alert-ready" ? { source: "alert-ready" as const, officialAlertKey: entry.official_alert_key ?? null } : {}),
  };
}

const deviceAlertInsertSql = `
  INSERT INTO device_alerts
    (id, institution_id, alert_type, title, message, area, status, target_device_ids, issued_by, created_by, created_at, expires_at, ended_at, image, image_storage_path)
  VALUES ($1, $2, $3, $4, $5, $6, 'active', $7::jsonb, $8, $9, $10, $11, NULL, $12::jsonb, $13)
`;

function materializeDeviceAlert(alert: Omit<DeviceAlert, "id" | "status" | "createdAt" | "endedAt">): DeviceAlert {
  const id = `ALT-${randomUUID().replace(/-/g, "").slice(0, 12).toUpperCase()}`;
  return {
    ...alert,
    id,
    image: alert.image ? { ...alert.image, url: `/api/institution/alerts/${id}/image` } : null,
    status: "active",
    createdAt: new Date().toISOString(),
    endedAt: null,
  };
}

function deviceAlertInsertParams(alert: DeviceAlert) {
  return [alert.id, alert.institutionId, alert.alertType, alert.title, alert.message, alert.area, JSON.stringify(alert.targetDeviceIds), alert.issuedBy, alert.createdBy, alert.createdAt, alert.expiresAt, JSON.stringify(alert.image ?? null)];
}

function mapUser(entry: UserRow): DbUser {
  return {
    screenScope:entry.screen_scope??null,
    id: entry.id,
    name: entry.name,
    email: entry.email,
    role: entry.role,
    status: entry.status === "banned" ? "banned" : "active",
    institutionId: entry.institution_id ?? null,
    operatorLimit: entry.role === "institutional" ? clampOperatorLimit(entry.operator_limit) : 0,
    createdAt: stringifyDate(entry.created_at),
  };
}

function mapTransaction(entry: TransactionRow): Transaction {
  return {
    id: entry.id,
    bookingId: entry.booking_id,
    advertiser: entry.advertiser,
    amount: Number(entry.amount),
    platformFee: Number(entry.platform_fee),
    operatorPayout: Number(entry.operator_payout),
    status: entry.status,
    method: entry.method,
    gatewayRef: entry.gateway_ref,
    createdAt: stringifyDate(entry.created_at),
    paidAt: entry.paid_at ? stringifyDate(entry.paid_at) : null,
  };
}

function mapPopLog(entry: PopLogRow): PopLog {
  return {
    id: entry.id,
    bookingId: entry.booking_id,
    inventoryId: entry.inventory_id,
    plays: Number(entry.plays),
    impressions: Number(entry.impressions),
    status: entry.status,
    source: entry.source,
    playedAt: stringifyDate(entry.played_at),
  };
}

function mapCreative(entry: CreativeRow): Creative {
  return {
    id: entry.id,
    bookingId: entry.booking_id,
    source: entry.source ?? "template",
    template: entry.template,
    format: entry.format,
    width: Number(entry.width),
    height: Number(entry.height),
    fileType: entry.file_type,
    fileSize: Number(entry.file_size),
    safeZone: Number(entry.safe_zone),
    distortion: Number(entry.distortion),
    originalName: entry.original_name,
    mimeType: entry.mime_type ?? (entry.source === "template" ? "text/html" : null),
    publicUrl: entry.public_url ?? (entry.source === "template" ? `/creative-html/${entry.id}` : null),
    status: entry.status,
    createdAt: stringifyDate(entry.created_at),
  };
}

function stringifyDate(value: unknown) {
  return value instanceof Date ? value.toISOString() : String(value);
}

function parseStringArray(value: unknown) {
  if (Array.isArray(value)) return value.filter((entry): entry is string => typeof entry === "string");
  if (typeof value === "string") {
    try {
      const parsed: unknown = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.filter((entry): entry is string => typeof entry === "string") : [];
    } catch {
      return [];
    }
  }
  return [];
}
