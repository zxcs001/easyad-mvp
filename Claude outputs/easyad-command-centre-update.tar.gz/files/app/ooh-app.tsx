"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { isRoleValue, isViewValue } from "./roles";
import { ApprovalEvent, Booking, Creative, DeviceAlert, FormatKey, InventoryItem, MediaResource, Role, Transaction, View } from "./data";
import { ONTARIO_LOCATION_ID, isRegionLocationId, loadRegionBoundaries, normalizeLocationId, ontarioLocation, regionContains, regionLocation, regionLocations, type RegionBoundaries } from "./lib/geo/regions";
import BookingView from "./component/booking-view";
import CampaignSpacesView from "./component/campaign-spaces-view";
import CampaignWorkspace from "./component/campaign-workspace";
import CreativeView from "./component/creative-view";
import { defaultCreativeHtml } from "./creative-templates";
import ContentLibraryView from "./component/content-library-view";
import { Sidebar, Topbar } from "./component/dashboard-shell";
import DiscoverView from "./component/discover-view";
import { ApprovalsView, CalendarView, InventoryView } from "./component/operator-views";
import AccountManagementView from "./component/account-management-view";
import InstitutionTeamView from "./component/institution-team-view";
import FleetOperations from "./component/fleet-operations";
import InstitutionNetworkView, { type EmergencyOverrideDraft } from "./component/institution-network-view";
import EmergencyUpdatesView from "./component/emergency-updates-view";
import InstitutionAdvertisingView from "./component/institution-advertising-view";
import { showsAdvertisingArea, type ScreenUse } from "./lib/screen-use-policy";
import Portal from "./component/portal";
import { EmptyState } from "./component/shared-ui";
import { BillingView, ReportsView } from "./component/reports-billing-views";
import type { BookingDraft, CreativeDraft, Filters, MapPoint } from "./types";
import type { DaypartId } from "./lib/booking-schedule";
import { CURRENT_LOCATION_ID, MANUAL_LOCATION_ID, creativeDraftForFormat, defaultBookingDates, defaultFilters, estimateSpend, exceedsLoopCapacity, geoToMapPoint, isKnownLocationId, mapDistanceKm, overlaps } from "./utils";
import type { DbUser } from "./lib/db";
import { canAccessInstitutionWorkspace } from "./roles";
import { SIDEBAR_COOKIE_MAX_AGE, SIDEBAR_COOKIE_NAME, readBrowserPreference, writeBrowserPreference } from "./lib/preferences";
import { useI18n } from "./i18n/client";
import type { FeatureFlags } from "./lib/feature-flags";
import { isInventoryAvailableForDates } from "./lib/inventory-availability";
import { isStaticInventory } from "./lib/inventory-delivery";
import { readCampaignCancellationResponse, readCreativeSubmissionResponse, resolveCampaignView, type CampaignCreationStep } from "./lib/campaign-creation-flow";

export default function OohApp({
  currentUser,
  initialInventoryData = [],
  initialBookingsData = [],
  initialMediaResources = [],
  initialDeviceAlerts = [],
  initialTransactions = [],
  initialApprovalHistory = [],
  initialCreatives = [],
  initialManagedUsers = [],
  initialInstitutionOperators = [],
  initialRole = "advertiser",
  initialView = "portal",
  initialNavCollapsed = false,
  initialFormat,
  initialFilters,
  initialLocationId,
  initialArea,
  initialMapZoom,
  initialInventoryId,
  initialCreative,
  initialBookingId,
  initialCreativeSubmitted = false,
  featureFlags = { campaign_model_v2: false, agency_workspace: false, static_fulfillment: false, payments: false },
  fleetToolsEnabled = false,
  playerControlEnabled = false,
  surface = "marketplace",
}: {
  currentUser?: DbUser | null;
  initialInventoryData?: InventoryItem[];
  initialBookingsData?: Booking[];
  initialMediaResources?: MediaResource[];
  initialDeviceAlerts?: DeviceAlert[];
  initialTransactions?: Transaction[];
  initialApprovalHistory?: ApprovalEvent[];
  initialCreatives?: Creative[];
  initialManagedUsers?: DbUser[];
  initialInstitutionOperators?: DbUser[];
  initialRole?: Role;
  initialView?: View;
  initialNavCollapsed?: boolean;
  initialFormat?: FormatKey;
  initialFilters?: Partial<Filters>;
  initialLocationId?: string;
  initialArea?: { x: number; y: number };
  initialMapZoom?: number;
  initialInventoryId?: string;
  initialCreative?: Partial<CreativeDraft>;
  initialBookingId?: string;
  initialCreativeSubmitted?: boolean;
  featureFlags?: FeatureFlags;
  /** FEATURE_FLEET_OPERATIONS. Adds the Fleet tools page for owners, operators and Super Admin. */
  fleetToolsEnabled?: boolean;
  /** FEATURE_PLAYER_CONTROL. Shows the Player connection tab in the command centre. */
  playerControlEnabled?: boolean;
  surface?: "marketplace" | "government";
}) {
  const { t } = useI18n();
  // The server reads the remembered choice from the cookie and passes it in, so
  // the first paint already has the right sidebar. Starting expanded and
  // adopting the cookie after mount painted a 244px sidebar that then snapped
  // to the 76px rail on a slow load. The effect below still reads the cookie,
  // for a page the server rendered without it.
  const [navCollapsed, setNavCollapsed] = useState(initialNavCollapsed);
  useEffect(() => {
    if (readBrowserPreference(SIDEBAR_COOKIE_NAME) === "1") setNavCollapsed(true);
  }, []);
  function toggleNavCollapsed() {
    setNavCollapsed((open) => {
      writeBrowserPreference(SIDEBAR_COOKIE_NAME, open ? "0" : "1", SIDEBAR_COOKIE_MAX_AGE);
      return !open;
    });
  }
  const startingRole = currentUser && currentUser.role !== "admin" ? currentUser.role : initialRole;
  const initialAccessibleBookingIds = new Set(initialBookingsData.map((booking) => booking.id));
  const safeInitialView = startingRole === "advertiser"
    ? resolveCampaignView({ requestedView: initialView, activeStep: null, bookingId: initialBookingId, accessibleBookingIds: initialAccessibleBookingIds })
    : initialView;
  const [role, setRole] = useState<Role>(startingRole);
  const [view, setView] = useState<View>(safeInitialView);
  const [selectedBookingId, setSelectedBookingId] = useState(initialBookingId && initialBookingsData.some((booking) => booking.id === initialBookingId) ? initialBookingId : initialBookingsData.find((booking) => booking.creativeStatus !== "approved")?.id ?? initialBookingsData[0]?.id ?? "");
  const [campaignCreationStep, setCampaignCreationStep] = useState<CampaignCreationStep>(null);
  const campaignCreationStepRef = useRef<CampaignCreationStep>(null);
  const accessibleBookingIdsRef = useRef(initialAccessibleBookingIds);
  const campaignCreationActive = campaignCreationStep !== null;

  function setCampaignCreationState(step: CampaignCreationStep) {
    campaignCreationStepRef.current = step;
    setCampaignCreationStep(step);
  }

  function navigateToView(nextView: View) {
    const guardedView = role === "advertiser"
      ? resolveCampaignView({
          requestedView: nextView,
          activeStep: campaignCreationStepRef.current,
          bookingId: nextView === "creative" ? selectedBookingId : null,
          accessibleBookingIds: accessibleBookingIdsRef.current,
        })
      : nextView;
    if (guardedView !== nextView) return;
    setView(guardedView);
  }

  // The address follows the view. It used to stay on the first page loaded, so
  // reload went back to that page, Back left the app, and a copied link opened
  // the wrong view. The ref holds what the address already says: the server
  // made it match on load, and Back updates it before changing the view, so
  // neither a double-run effect nor a Back press pushes an extra entry.
  const addressState = useRef({ role, view, bookingId: view === "creative" ? selectedBookingId : "" });
  useEffect(() => {
    const bookingId = view === "creative" ? selectedBookingId : "";
    if (addressState.current.role === role && addressState.current.view === view && addressState.current.bookingId === bookingId) return;
    addressState.current = { role, view, bookingId };
    const url = new URL(window.location.href);
    if (surface === "government") url.searchParams.delete("role");
    else url.searchParams.set("role", role);
    url.searchParams.set("view", view);
    // The command centre keeps its open tab in ?panel=; other views have none.
    if (view !== "network") url.searchParams.delete("panel");
    if (bookingId) url.searchParams.set("bookingId", bookingId);
    else url.searchParams.delete("bookingId");
    if (url.href !== window.location.href) window.history.pushState(window.history.state, "", url);
  }, [role, selectedBookingId, surface, view]);

  // Back and Forward restore the view, and the role where it can change.
  useEffect(() => {
    function restoreFromAddress() {
      const params = new URLSearchParams(window.location.search);
      const requestedView = params.get("view");
      const requestedRole = params.get("role");
      const requestedBookingId = params.get("bookingId");
      const nextView = isViewValue(requestedView) ? requestedView : initialView;
      const canChangeRole = surface !== "government" && (!currentUser || currentUser.role === "admin");
      const nextRole = canChangeRole && isRoleValue(requestedRole) ? requestedRole : startingRole;
      const guardedView = nextRole === "advertiser"
        ? resolveCampaignView({ requestedView: nextView, activeStep: campaignCreationStepRef.current, bookingId: requestedBookingId, accessibleBookingIds: accessibleBookingIdsRef.current })
        : nextView;
      if (guardedView !== nextView) {
        const lockedUrl = new URL(window.location.href);
        if (surface !== "government") lockedUrl.searchParams.set("role", role);
        lockedUrl.searchParams.set("view", guardedView);
        if (guardedView === "creative" && selectedBookingId) lockedUrl.searchParams.set("bookingId", selectedBookingId);
        else lockedUrl.searchParams.delete("bookingId");
        window.history.pushState(window.history.state, "", lockedUrl);
        return;
      }
      addressState.current = { role: nextRole, view: nextView, bookingId: requestedBookingId ?? "" };
      if (nextView === "creative" && requestedBookingId) setSelectedBookingId(requestedBookingId);
      setRole(nextRole);
      setView(nextView);
    }
    window.addEventListener("popstate", restoreFromAddress);
    return () => window.removeEventListener("popstate", restoreFromAddress);
  }, [currentUser, initialView, role, selectedBookingId, startingRole, surface]);

  useEffect(() => {
    if (!campaignCreationActive) return;
    function protectDraft(event: BeforeUnloadEvent) {
      event.preventDefault();
      event.returnValue = "";
    }
    window.addEventListener("beforeunload", protectDraft);
    return () => window.removeEventListener("beforeunload", protectDraft);
  }, [campaignCreationActive]);
  // No saved location: show Ontario first, then move to the visitor's own
  // location if the browser shares it.
  const [selectedLocationId, setSelectedLocationIdState] = useState(() => {
    const requested = normalizeLocationId(initialLocationId);
    return requested && isKnownLocationId(requested) ? requested : ONTARIO_LOCATION_ID;
  });
  const selectedLocationIdRef = useRef(selectedLocationId);
  selectedLocationIdRef.current = selectedLocationId;
  // Once the person picks a location, a late geolocation answer must not replace it.
  const locationChosenRef = useRef(Boolean(initialLocationId && initialLocationId !== CURRENT_LOCATION_ID) || Boolean(initialArea));
  const [locating, setLocating] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<MapPoint | null>(
    initialArea && initialLocationId && [CURRENT_LOCATION_ID, MANUAL_LOCATION_ID].includes(initialLocationId)
      ? { id: initialLocationId, label: initialLocationId === MANUAL_LOCATION_ID ? "Selected map area" : "Current location", ...initialArea }
      : null,
  );
  const [selectedInventoryId, setSelectedInventoryId] = useState(initialInventoryId && initialInventoryData.some((item) => item.id === initialInventoryId) ? initialInventoryId : initialInventoryData[0]?.id ?? "");
  const [filters, setFilters] = useState<Filters>(() => {
    const loadedFilters = compactFilters(initialFilters);
    return {
      ...defaultFilters,
      ...loadedFilters,
      format: initialFormat ?? loadedFilters.format ?? "all",
      selectedTags: loadedFilters.selectedTags ?? [],
    };
  });
  const [inventory, setInventory] = useState<InventoryItem[]>(initialInventoryData);
  const [mediaResources, setMediaResources] = useState<MediaResource[]>(initialMediaResources);
  const [deviceAlerts, setDeviceAlerts] = useState<DeviceAlert[]>(initialDeviceAlerts);
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [approvalHistory, setApprovalHistory] = useState<ApprovalEvent[]>(initialApprovalHistory);
  const [creatives, setCreatives] = useState<Creative[]>(initialCreatives);
  const [managedUsers, setManagedUsers] = useState<DbUser[]>(initialManagedUsers);
  const [institutionOperators, setInstitutionOperators] = useState<DbUser[]>(initialInstitutionOperators);
  const [bookings, setBookings] = useState<Booking[]>(() => {
    let loadedBookings = initialBookingsData;
    if (initialCreativeSubmitted && initialBookingId) {
      loadedBookings = loadedBookings.map((booking) => (booking.id === initialBookingId ? { ...booking, creativeStatus: "pending review", status: "creative review" } : booking));
    }
    return loadedBookings;
  });
  const [bookingDraft, setBookingDraft] = useState<BookingDraft>({
    campaign: "Launch Campaign",
    ...defaultBookingDates(),
    advertiser: currentUser?.name ?? "New Advertiser",
    adSlots: 1,
  });
  const [creativeDraft, setCreativeDraft] = useState<CreativeDraft>({
    template: "retail",
    format: "digital",
    width: 1920,
    height: 1080,
    fileType: "png",
    fileSize: 84,
    safeZone: 10,
    distortion: 1,
    ...initialCreative,
  });

  useEffect(() => {
    document.title = `${t(documentTitleByView[view])} — ${t(surface === "government" ? "Civic Screen Operations" : "EasyAD Platform")}`;
  }, [surface, t, view]);

  // Ask for the visitor's location the first time a map view opens on the
  // marketplace. Without it (denied, unsupported, timed out) the map stays on
  // Ontario. The institution workspace centres on its own fleet instead.
  const geolocationRequestedRef = useRef(false);
  const wantsGeolocation = surface === "marketplace" && !initialArea && (!initialLocationId || initialLocationId === CURRENT_LOCATION_ID) && ["portal", "discover", "booking"].includes(view);
  function requestCurrentLocation({ fromUser = false } = {}) {
    if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
      if (selectedLocationIdRef.current === CURRENT_LOCATION_ID) setSelectedLocationIdState(ONTARIO_LOCATION_ID);
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocating(false);
        if (!fromUser && locationChosenRef.current) return;
        setCurrentLocation({
          id: CURRENT_LOCATION_ID,
          label: "Current location",
          level: "point",
          ...geoToMapPoint(position.coords.latitude, position.coords.longitude),
        });
        setSelectedLocationIdState(CURRENT_LOCATION_ID);
      },
      () => {
        setLocating(false);
        if (selectedLocationIdRef.current === CURRENT_LOCATION_ID) setSelectedLocationIdState(ONTARIO_LOCATION_ID);
      },
      { enableHighAccuracy: false, maximumAge: 300000, timeout: 8000 },
    );
  }
  useEffect(() => {
    if (!wantsGeolocation || geolocationRequestedRef.current) return;
    geolocationRequestedRef.current = true;
    requestCurrentLocation();
    // requestCurrentLocation reads refs only; it does not need to re-run.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wantsGeolocation]);

  function setSelectedLocationId(id: string) {
    locationChosenRef.current = true;
    if (id === CURRENT_LOCATION_ID && currentLocation?.id !== CURRENT_LOCATION_ID) {
      setSelectedLocationIdState(CURRENT_LOCATION_ID);
      requestCurrentLocation({ fromUser: true });
      return;
    }
    setSelectedLocationIdState(id);
  }

  // A search result: a region is selected by its id; a point (a street result
  // or a device) becomes the search centre.
  function selectSearchLocation(location: MapPoint) {
    locationChosenRef.current = true;
    if (isRegionLocationId(location.id)) {
      setSelectedLocationIdState(normalizeLocationId(location.id)!);
      return;
    }
    setCurrentLocation({ ...location, id: MANUAL_LOCATION_ID, level: "point", bounds: undefined });
    setSelectedLocationIdState(MANUAL_LOCATION_ID);
  }

  const locationOptions = useMemo(() => currentLocation ? [currentLocation, ...regionLocations] : regionLocations, [currentLocation]);
  const selectedLocation: MapPoint =
    [CURRENT_LOCATION_ID, MANUAL_LOCATION_ID].includes(selectedLocationId) && currentLocation
      ? currentLocation
      : regionLocation(selectedLocationId) ?? ontarioLocation;
  const selectedRegion = selectedLocation.bounds ? selectedLocation : null;

  // County boundaries load only once a region filters the list. Until then
  // the bounding box stands in.
  const [regionBoundaries, setRegionBoundaries] = useState<RegionBoundaries | null>(null);
  useEffect(() => {
    if (!selectedRegion || regionBoundaries) return;
    let cancelled = false;
    void loadRegionBoundaries().then((boundaries) => { if (!cancelled) setRegionBoundaries(boundaries); }).catch(() => undefined);
    return () => { cancelled = true; };
  }, [regionBoundaries, selectedRegion]);

  const visibleInventory = useMemo(
    () =>
      inventory
        // A region lists every screen inside it, so the distance (from the
        // region's centre) only orders the list and is not shown.
        .map((item) => ({ ...item, distance: mapDistanceKm(selectedLocation, item), withinArea: selectedRegion ? regionContains(selectedRegion, item, regionBoundaries) : undefined }))
        .filter((item) => item.withinArea ?? item.distance <= filters.radius)
        .filter((item) => filters.format === "all" || item.format === filters.format)
        .filter((item) => item.impressions >= filters.minImpressions)
        .filter((item) => item.traffic >= filters.minTraffic)
        .filter((item) => item.income >= filters.minIncome)
        .filter((item) => filters.audience === "all" || item.audience === filters.audience)
        .filter((item) => filters.competitor === "all" || item.competitor === filters.competitor)
        .filter((item) => !filters.selectedTags.length || filters.selectedTags.every((tag) => item.tags?.includes(tag)))
        .filter((item) => item.price <= filters.priceMax)
        .sort((a, b) => a.distance - b.distance)
        .map(({ withinArea, ...item }) => ({ ...item, distance: withinArea === undefined ? item.distance : Number.NaN })),
    [filters, inventory, regionBoundaries, selectedLocation, selectedRegion],
  );
  // Only Find screens and Request dates choose from the filtered list. Inventory
  // and the other management views list every device, and used to search the
  // radius-filtered list first: clicking a device outside the radius
  // highlighted its row while the form showed another device, and Save failed.
  const selectsFromFilteredList = view === "discover" || view === "booking";
  const selectedInventory = selectsFromFilteredList
    ? visibleInventory.find((item) => item.id === selectedInventoryId) ?? visibleInventory[0] ?? inventory.find((item) => item.id === selectedInventoryId) ?? inventory[0]
    : inventory.find((item) => item.id === selectedInventoryId) ?? inventory[0];
  const canManageInventory = currentUser?.role === "operator" || currentUser?.role === "institutional" || currentUser?.role === "admin";
  const canDeleteInventory = currentUser?.role === "admin";
  const canBuyAds = currentUser?.role === "advertiser" || currentUser?.role === "admin";
  const institutionNetworkInventory = useMemo(() => currentUser?.role === "admin" ? inventory.filter((item) => Boolean(item.institutionId)) : inventory, [currentUser?.role, inventory]);
  const networkSelectedInventory = institutionNetworkInventory.find((item) => item.id === selectedInventoryId) ?? institutionNetworkInventory[0] ?? null;
  const institutionNetworkIds = new Set(institutionNetworkInventory.map((item) => item.id));
  const institutionNetworkMedia = mediaResources.filter((resource) => institutionNetworkIds.has(resource.inventoryId));
  const selectedInstitution = currentUser?.role === "admin" && networkSelectedInventory?.institutionId
    ? managedUsers.find((user) => user.id === networkSelectedInventory.institutionId && user.role === "institutional")
    : null;
  const networkInstitutionName = currentUser?.role === "admin" ? selectedInstitution?.name ?? "the selected institution" : currentUser?.name ?? "this institution";
  const isGovernmentSurface = surface === "government";
  // The institution workspace shows commercial views only once a screen is
  // open to private-sector advertising, or advertising history remains.
  const showAdvertising = isGovernmentSurface && showsAdvertisingArea(institutionNetworkInventory, bookings);
  const showFleetTools = fleetToolsEnabled && ["admin", "institutional", "operator"].includes(currentUser?.role ?? "");

  function launchPortal(nextRole: Role, nextView: View) {
    if (!currentUser) return;
    if (currentUser.role !== "admin" && nextRole !== currentUser.role) return;
    setRole(currentUser && currentUser.role !== "admin" ? currentUser.role : nextRole);
    setView(nextView);
  }

  function selectFormat(format: FormatKey) {
    if (!currentUser || (currentUser.role !== "advertiser" && currentUser.role !== "admin")) return;
    setRole("advertiser");
    setView("discover");
    setFilters((current) => ({ ...current, format }));
  }

  function hasCapacityConflict(inventoryId: string, start: string, end: string, adSlots = 1, excludeId = "", dayparts: DaypartId[] = []) {
    const item = inventory.find((unit) => unit.id === inventoryId);
    if (!item) return true;
    if (isStaticInventory(item)) return !isInventoryAvailableForDates(item, start, end);
    return exceedsLoopCapacity(item, bookings, start, end, adSlots, excludeId, dayparts);
  }

  async function submitBooking(file?: File | null) {
    if (!canBuyAds || !selectedInventory) return false;
    // Time-of-day slots apply to digital screens only. A draft keeps them while
    // the person browses, so a billboard request drops them here.
    const dayparts = isStaticInventory(selectedInventory) ? [] : bookingDraft.dayparts ?? [];
    if (hasCapacityConflict(selectedInventory.id, bookingDraft.start, bookingDraft.end, bookingDraft.adSlots, "", dayparts)) return false;
    const body = new FormData();
    if (file) body.set("file", file);
    body.set("inventoryId", selectedInventory.id);
    body.set("advertiser", bookingDraft.advertiser);
    body.set("campaign", bookingDraft.campaign);
    body.set("start", bookingDraft.start);
    body.set("end", bookingDraft.end);
    body.set("adSlots", String(bookingDraft.adSlots));
    if (dayparts.length) body.set("dayparts", dayparts.join(","));
    const response = await fetch("/api/bookings", {
      method: "POST",
      body,
    });
    if (!response.ok) {
      const payload = await response.json().catch(() => null) as { error?: string } | null;
      throw new Error(payload?.error ?? "Could not submit this date request. Your details are still here—please try again.");
    }
    const payload = await response.json() as { booking: Booking; creative: Creative | null };
    setBookings((current) => [payload.booking, ...current]);
    if (payload.creative) setCreatives((current) => [payload.creative!, ...current]);
    accessibleBookingIdsRef.current.add(payload.booking.id);
    setSelectedBookingId(payload.booking.id);
    setCampaignCreationState("creative");
    setView("creative");
    return true;
  }

  function cancelCampaignCreation() {
    setBookingDraft({
      campaign: "Launch Campaign",
      ...defaultBookingDates(),
      advertiser: currentUser?.name ?? "New Advertiser",
      adSlots: 1,
    });
    setCampaignCreationState(null);
    setView("discover");
  }

  async function cancelCreative(bookingId: string) {
    const creating = campaignCreationStepRef.current === "creative";
    if (creating) {
      if (bookingId !== selectedBookingId) throw new Error("Select the campaign being created before cancelling.");
      const response = await fetch(`/api/bookings/${bookingId}/cancel`, { method: "POST" })
        .catch(() => { throw new Error("Could not connect to the server. Your campaign has not been confirmed cancelled; please retry."); });
      const booking = await readCampaignCancellationResponse(response, bookingId);
      setBookings((current) => current.map((entry) => entry.id === bookingId ? booking : entry));
    }
    setCreativeDraft({ template: "retail", format: "digital", width: 1920, height: 1080, fileType: "png", fileSize: 1, safeZone: 10, distortion: 1 });
    if (creating) cancelCampaignCreation();
    else setView("campaigns");
    return true;
  }

  async function addInventory(draft: InventoryItem) {
    if (!canManageInventory) return false;
    const item: InventoryItem = {
      ...draft,
      id: `INV-${Math.floor(600 + Math.random() * 3000)}`,
    };
    const response = await fetch("/api/inventory", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(item),
    });
    if (!response.ok) return false;
    const payload = await response.json() as { item: InventoryItem };
    setInventory((current) => [...current, payload.item]);
    setSelectedInventoryId(payload.item.id);
    return true;
  }

  async function saveInventory(item: InventoryItem) {
    if (!canManageInventory || !selectedInventory || item.id !== selectedInventory.id) return false;
    const { approvalStatus: _approvalStatus, ...operatorEditableFields } = item;
    const requestBody = currentUser?.role === "admin" ? item : operatorEditableFields;
    const response = await fetch(`/api/inventory/${item.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody),
    });
    if (!response.ok) return false;
    const payload = await response.json() as { item: InventoryItem };
    setInventory((current) => current.map((existing) => existing.id === item.id ? payload.item : existing));
    return true;
  }

  async function updateInventoryApproval(id: string, approvalStatus: NonNullable<InventoryItem["approvalStatus"]>) {
    if (currentUser?.role !== "admin") return false;
    const response = await fetch(`/api/inventory/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approvalStatus }),
    });
    if (!response.ok) return false;
    const payload = await response.json() as { item: InventoryItem };
    setInventory((current) => current.map((item) => (item.id === id ? payload.item : item)));
    return true;
  }

  async function deleteInventory() {
    if (!canDeleteInventory || !selectedInventory) return;
    const response = await fetch(`/api/inventory/${selectedInventory.id}`, { method: "DELETE" });
    if (!response.ok) return;
    setInventory((current) => {
      const next = current.filter((item) => item.id !== selectedInventory.id);
      setSelectedInventoryId(next[0]?.id ?? "");
      return next;
    });
    setMediaResources((current) => current.filter((resource) => resource.inventoryId !== selectedInventory.id));
  }

  async function updateBooking(id: string, updates: Partial<Booking>) {
    const response = await fetch(`/api/bookings/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    if (!response.ok) return false;
    const payload = await response.json() as { booking: Booking; approval: ApprovalEvent | null };
    setBookings((current) => current.map((booking) => (booking.id === id ? payload.booking : booking)));
    const approval = payload.approval;
    if (approval) setApprovalHistory((current) => [approval, ...current]);
    return true;
  }

  async function submitCreative(bookingId: string, source: Creative["source"], file?: File | null) {
    if (!canBuyAds) throw new Error("Sign in as an advertiser to submit campaign creative.");
    const booking = bookings.find((entry) => entry.id === bookingId);
    const item = inventory.find((entry) => entry.id === booking?.inventoryId);
    if (!item) throw new Error("The booked placement is no longer available. Refresh your campaign before submitting artwork.");
    if (isStaticInventory(item) && source !== "upload") throw new Error("Static billboards require uploaded artwork. Choose a PNG, JPG, or PDF file.");
    if (source === "upload" && !file) throw new Error("Choose a media file before submitting your creative.");
    const draft = creativeDraftForFormat(creativeDraft, item.format);
    const { htmlByTopic, ...creativeFields } = draft;
    const body = source === "upload" && file ? creativeUploadForm(draft, file) : JSON.stringify({
      ...creativeFields,
      html: htmlByTopic?.[draft.template] ?? defaultCreativeHtml[draft.template],
    });
    const response = await fetch(`/api/bookings/${bookingId}/creative`, {
      method: "POST",
      headers: source === "upload" && file ? undefined : { "Content-Type": "application/json" },
      body,
    }).catch(() => { throw new Error("Could not connect to the server. Check your connection and retry; your artwork is still selected."); });
    const payload = await readCreativeSubmissionResponse(response, bookingId);
    setBookings((current) => current.map((booking) => (booking.id === bookingId ? payload.booking : booking)));
    setCreatives((current) => [payload.creative, ...current]);
    setCampaignCreationState(null);
    setView("campaigns");
    return true;
  }

  async function settleInvoice(bookingId: string, action: "pay" | "refund") {
    const response = await fetch(`/api/bookings/${bookingId}/payment`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action }),
    });
    if (!response.ok) return false;
    const payload = await response.json() as { booking: Booking; transaction: Transaction };
    setBookings((current) => current.map((booking) => (booking.id === bookingId ? payload.booking : booking)));
    setTransactions((current) => {
      const others = current.filter((transaction) => transaction.bookingId !== bookingId);
      return payload.transaction ? [payload.transaction, ...others] : others;
    });
    return true;
  }

  async function runDeliveryTick() {
    const response = await fetch("/api/pop/run", { method: "POST" });
    if (!response.ok) return false;
    const payload = await response.json() as { bookings: Booking[] };
    setBookings(payload.bookings);
    return true;
  }

  async function uploadInventoryMedia(file: File, title: string, inventoryId = selectedInventory?.id) {
    if (!canManageInventory || !inventoryId) return false;
    const form = new FormData();
    form.set("file", file);
    form.set("title", title);
    const response = await fetch(`/api/inventory/${inventoryId}/media`, { method: "POST", body: form });
    if (!response.ok) {
      const payload = await response.json().catch(() => null) as { error?: string } | null;
      throw new Error(payload?.error ?? "Upload failed. Please try again.");
    }
    const payload = await response.json() as { resource: MediaResource };
    setMediaResources((current) => [payload.resource, ...current]);
    return true;
  }

  async function deleteMediaResource(id: string) {
    if (!canManageInventory) return false;
    const response = await fetch(`/api/media/${id}`, { method: "DELETE" });
    if (!response.ok) return false;
    setMediaResources((current) => current.filter((resource) => resource.id !== id));
    return true;
  }

  async function updateMediaApproval(id: string, approvalStatus: Extract<MediaResource["approvalStatus"], "approved" | "rejected">) {
    if (!canAccessInstitutionWorkspace(currentUser?.role)) return false;
    const response = await fetch(`/api/media/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approvalStatus }),
    });
    if (!response.ok) return false;
    const payload = await response.json() as { resource: MediaResource };
    setMediaResources((current) => current.map((resource) => resource.id === id ? payload.resource : resource));
    return true;
  }

  async function saveScreenSettings(id: string, settings: import("./component/screen-settings-dialog").ScreenSettings) {
    if (!canAccessInstitutionWorkspace(currentUser?.role)) return { error: "Institution account or Super Admin access required" };
    try {
      const response = await fetch(`/api/inventory/${encodeURIComponent(id)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      const payload = await response.json().catch(() => ({})) as { item?: InventoryItem; error?: string };
      if (!response.ok || !payload.item) return { error: payload.error ?? "Unable to save display settings. Try again." };
      setInventory((current) => current.map((item) => item.id === id ? payload.item! : item));
      return { value: payload.item };
    } catch {
      return { error: "Unable to save display settings. Try again." };
    }
  }

  async function setScreenUse(id: string, use: ScreenUse) {
    if (!canAccessInstitutionWorkspace(currentUser?.role)) return { error: "Institution account or Super Admin access required" };
    const current = inventory.find((item) => item.id === id);
    try {
      const response = await fetch(`/api/institution/screens/${encodeURIComponent(id)}/use`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ use, version: current?.fleetVersion }),
      });
      const payload = await response.json().catch(() => ({})) as { item?: InventoryItem; error?: string };
      if (!response.ok || !payload.item) return { error: payload.error ?? "Screen use could not be changed" };
      setInventory((items) => items.map((item) => item.id === id ? payload.item! : item));
      return { value: payload.item };
    } catch {
      return { error: "Unable to reach the screen service. Try again." };
    }
  }

  async function setInventoryPublishState(id: string, published: boolean) {
    if (!canAccessInstitutionWorkspace(currentUser?.role)) return { error: "Institution account or Super Admin access required" };
    try {
      const response = await fetch(`/api/inventory/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ approvalStatus: published ? "approved" : "pending approval" }),
      });
      const payload = await response.json().catch(() => ({})) as { item?: InventoryItem; error?: string };
      if (!response.ok || !payload.item) return { error: payload.error ?? "Unable to update screen publishing" };
      setInventory((current) => current.map((item) => item.id === id ? payload.item! : item));
      return { value: payload.item };
    } catch {
      return { error: "Unable to reach the publishing service. Try again." };
    }
  }

  async function createEmergencyOverride(draft: EmergencyOverrideDraft) {
    if (!canAccessInstitutionWorkspace(currentUser?.role)) return { error: "Institution account or Super Admin access required" };
    try {
      const { imageFile, ...details } = draft;
      const form = imageFile ? new FormData() : null;
      if (form && imageFile) { form.set("draft", JSON.stringify(details)); form.set("image", imageFile); }
      const response = await fetch("/api/institution/alerts", {
        method: "POST",
        headers: form ? undefined : { "Content-Type": "application/json" },
        body: form ?? JSON.stringify(details),
      });
      const payload = await response.json().catch(() => ({})) as { alert?: DeviceAlert; error?: string };
      if (!response.ok || !payload.alert) return { error: payload.error ?? "Unable to publish the emergency override" };
      setDeviceAlerts((current) => [payload.alert!, ...current]);
      return { value: payload.alert };
    } catch {
      return { error: "Unable to reach the alert service. The override was not published." };
    }
  }

  async function endEmergencyOverride(id: string) {
    if (!canAccessInstitutionWorkspace(currentUser?.role)) return { error: "Institution account or Super Admin access required" };
    try {
      const response = await fetch(`/api/institution/alerts/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "end" }),
      });
      const payload = await response.json().catch(() => ({})) as { alert?: DeviceAlert; error?: string };
      if (!response.ok || !payload.alert) return { error: payload.error ?? "Unable to end the emergency override" };
      setDeviceAlerts((current) => current.map((alert) => alert.id === id ? payload.alert! : alert));
      return { value: payload.alert };
    } catch {
      return { error: "Unable to reach the alert service. The override remains active." };
    }
  }

  async function createManagedUser(account: { name: string; email: string; password: string; role: Exclude<Role, "admin">; institutionId: string | null; operatorLimit: number }) {
    if (currentUser?.role !== "admin") return { error: "Only super admins can create accounts" };
    const response = await fetch("/api/admin/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(account),
    });
    const payload = await response.json().catch(() => ({})) as { user?: DbUser; error?: string };
    if (!response.ok || !payload.user) return { error: payload.error ?? "Unable to create account" };
    setManagedUsers((current) => [payload.user!, ...current]);
    return { user: payload.user };
  }

  async function updateManagedUser(id: string, updates: { role: Exclude<Role, "admin">; status: DbUser["status"]; institutionId: string | null; operatorLimit: number }) {
    if (currentUser?.role !== "admin") return false;
    const response = await fetch(`/api/admin/users/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updates),
    });
    if (!response.ok) return false;
    const payload = await response.json() as { user: DbUser };
    setManagedUsers((current) => current.map((user) => user.id === id ? payload.user : user));
    return true;
  }

  async function deleteManagedUser(id: string) {
    if (currentUser?.role !== "admin") return false;
    const response = await fetch(`/api/admin/users/${id}`, { method: "DELETE" });
    if (!response.ok) return false;
    setManagedUsers((current) => current.filter((user) => user.id !== id && user.institutionId !== id));
    return true;
  }

  async function createInstitutionOperator(operator: { name: string; email: string; password: string }) {
    if (currentUser?.role !== "institutional") return { error: "Only institution accounts can create operators" };
    const response = await fetch("/api/institution/operators", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(operator),
    });
    const payload = await response.json().catch(() => ({})) as { user?: DbUser; error?: string };
    if (!response.ok || !payload.user) return { error: payload.error ?? "Unable to create operator" };
    setInstitutionOperators((current) => [payload.user!, ...current]);
    return { user: payload.user };
  }

  async function deleteInstitutionOperator(id: string) {
    if (currentUser?.role !== "institutional") return false;
    const response = await fetch(`/api/institution/operators/${id}`, { method: "DELETE" });
    if (!response.ok) return false;
    setInstitutionOperators((current) => current.filter((operator) => operator.id !== id));
    return true;
  }

  function selectMapArea(point: { x: number; y: number }) {
    locationChosenRef.current = true;
    setCurrentLocation({ id: MANUAL_LOCATION_ID, label: "Selected map area", level: "point", x: point.x, y: point.y });
    setSelectedLocationIdState(MANUAL_LOCATION_ID);
  }

  function renderDashboardView() {
    switch (view) {
      case "emergency":
        if (!canAccessInstitutionWorkspace(currentUser?.role)) return <EmptyInventoryPanel canManage={false} />;
        return <EmergencyUpdatesView institutionId={currentUser?.role === "institutional" ? currentUser.id : ""} institutionName={currentUser?.name ?? ""} institutions={currentUser?.role === "admin" ? managedUsers.filter(user => user.role === "institutional").map(({ id, name }) => ({ id, name })) : []} onCreate={createEmergencyOverride} onEnd={endEmergencyOverride} />;
      case "fleet":
        if (!showFleetTools) return null;
        return <FleetOperations />;
      case "network":
        if (!canAccessInstitutionWorkspace(currentUser?.role)) return null;
        return <InstitutionNetworkView playerControlEnabled={playerControlEnabled} institutionName={networkInstitutionName} isSuperAdmin={currentUser?.role === "admin"} inventory={institutionNetworkInventory} mediaResources={institutionNetworkMedia} bookings={bookings} creatives={creatives} alerts={deviceAlerts} selectedId={selectedInventoryId} onSelect={setSelectedInventoryId} onOpenInventory={(id) => { if (id) setSelectedInventoryId(id); setView("inventory"); }} onUploadMedia={async (deviceId, file, title) => { try { return await uploadInventoryMedia(file, title, deviceId) ? { value: true as const } : { error: "Unable to upload this content" }; } catch (error) { return { error: error instanceof Error ? error.message : "Unable to upload this content" }; } }} onSaveSettings={saveScreenSettings} onSetPublishState={setInventoryPublishState} onSetScreenUse={setScreenUse} onOpenAdvertising={() => navigateToView("advertising")} onCreateAlert={createEmergencyOverride} onEndAlert={endEmergencyOverride} />;
      case "discover":
        if (!selectedInventory) return <EmptyInventoryPanel canManage={canManageInventory} />;
        return (
          <DiscoverView
            filters={filters}
            setFilters={setFilters}
            selectedLocationId={selectedLocationId}
            setSelectedLocationId={setSelectedLocationId}
            selectedLocation={selectedLocation}
            onAreaChange={selectMapArea}
            onLocationChange={selectSearchLocation}
            locating={locating}
            mapZoom={initialMapZoom}
            locationOptions={locationOptions}
            selectedInventory={selectedInventory}
            selectedInventoryId={selectedInventory.id}
            setSelectedInventoryId={setSelectedInventoryId}
            visibleInventory={visibleInventory}
            inventory={inventory}
            bookings={bookings}
            onBook={() => {
              setRole("advertiser");
              setCampaignCreationState("booking");
              setView("booking");
            }}
            canComment={Boolean(currentUser)}
          />
        );
      case "booking":
        if (!selectedInventory) return <EmptyInventoryPanel canManage={canManageInventory} />;
        return (
          <BookingView
            advertiserNameFixed={currentUser?.role === "advertiser"}
            item={selectedInventory}
            inventory={inventory}
            draft={bookingDraft}
            bookings={bookings}
            setDraft={setBookingDraft}
            hasCapacityConflict={hasCapacityConflict}
            onSubmit={submitBooking}
            onCancel={cancelCampaignCreation}
            canBuy={canBuyAds}
            allowCreativeUpload={false}
          />
        );
      case "campaigns":
        if (featureFlags.campaign_model_v2) return <CampaignWorkspace inventory={inventory} currentRole={currentUser?.role} />;
        return (
          <CampaignSpacesView
            bookings={bookings}
            inventory={inventory}
            currentUser={currentUser}
            onOpenCreative={(booking) => {
              setCampaignCreationState(null);
              setSelectedBookingId(booking.id);
              setSelectedInventoryId(booking.inventoryId);
              setRole("advertiser");
              setView("creative");
            }}
          />
        );
      case "creative":
        return <CreativeView draft={creativeDraft} setDraft={setCreativeDraft} bookings={bookings} inventory={inventory} creatives={creatives} onSubmit={submitCreative} onCancel={cancelCreative} canSubmit={canBuyAds} selectedBookingId={selectedBookingId} setSelectedBookingId={setSelectedBookingId} lockBookingSelection={campaignCreationStep === "creative"} />;
      case "resources":
        return <ContentLibraryView currentUser={currentUser} inventory={inventory} bookings={bookings} creatives={creatives} mediaResources={mediaResources} onDeleteMedia={deleteMediaResource} onOpenCreative={(booking) => { setCampaignCreationState(null); setSelectedBookingId(booking.id); setSelectedInventoryId(booking.inventoryId); setView("creative"); }} onOpenInventory={(inventoryId) => { setSelectedInventoryId(inventoryId); setView("inventory"); }} />;
      case "inventory":
        if (!selectedInventory) return <InventoryView inventory={inventory} selectedId={selectedInventoryId} select={setSelectedInventoryId} item={newInventoryTemplate()} newItem={newInventoryTemplate()} mediaResources={[]} addInventory={addInventory} deleteInventory={deleteInventory} saveInventory={saveInventory} updateInventoryApproval={updateInventoryApproval} uploadMedia={uploadInventoryMedia} deleteMediaResource={deleteMediaResource} canManage={canManageInventory} canDelete={canDeleteInventory} approvalRequired={currentUser?.role === "operator"} institutionMode={isGovernmentSurface} />;
        return (
          <InventoryView
            inventory={inventory}
            selectedId={selectedInventoryId}
            select={setSelectedInventoryId}
            item={selectedInventory}
            newItem={newInventoryTemplate()}
            mediaResources={mediaResources.filter((resource) => resource.inventoryId === selectedInventory?.id)}
            addInventory={addInventory}
            deleteInventory={deleteInventory}
            saveInventory={saveInventory}
            updateInventoryApproval={updateInventoryApproval}
            uploadMedia={uploadInventoryMedia}
            deleteMediaResource={deleteMediaResource}
            canManage={canManageInventory}
            canDelete={canDeleteInventory}
            approvalRequired={currentUser?.role === "operator"}
            institutionMode={isGovernmentSurface}
          />
        );
      case "calendar":
        return <CalendarView inventory={inventory} bookings={bookings} />;
      case "approvals":
        if (isGovernmentSurface) return <ApprovalsView mode="content" bookings={[]} inventory={inventory} creatives={[]} mediaResources={mediaResources} canReviewDeviceContent={canAccessInstitutionWorkspace(currentUser?.role)} approvalHistory={[]} hasConflict={() => false} updateBooking={updateBooking} updateMediaApproval={updateMediaApproval} />;
        return <ApprovalsView bookings={bookings} inventory={inventory} creatives={creatives} mediaResources={mediaResources} canReviewDeviceContent={canAccessInstitutionWorkspace(currentUser?.role)} approvalHistory={approvalHistory} hasConflict={(inventoryId, start, end, excludeId) => hasCapacityConflict(inventoryId, start, end, bookings.find((booking) => booking.id === excludeId)?.adSlots ?? 1, excludeId)} updateBooking={updateBooking} updateMediaApproval={updateMediaApproval} />;
      case "accounts":
        if (currentUser?.role === "institutional") return <InstitutionTeamView institution={currentUser} operators={institutionOperators} onCreateOperator={createInstitutionOperator} onDeleteOperator={deleteInstitutionOperator} />;
        if (currentUser?.role === "admin") return <AccountManagementView users={managedUsers} bookings={bookings} inventory={inventory} creatives={creatives} mediaResources={mediaResources} onCreateAccount={createManagedUser} onUpdateAccount={updateManagedUser} onDeleteAccount={deleteManagedUser} />;
        return null;
      case "reports":
        return <ReportsView bookings={bookings} inventory={inventory} transactions={transactions} onRunDelivery={runDeliveryTick} canRunDelivery={canManageInventory} isAdvertiser={role === "advertiser"} />;
      case "billing":
        return <BillingView bookings={bookings} transactions={transactions} onSettle={settleInvoice} canManage={canManageInventory} isAdvertiser={role === "advertiser"} paymentsEnabled={featureFlags.payments} />;
      case "advertising":
        if (!canAccessInstitutionWorkspace(currentUser?.role)) return null;
        return (
          <InstitutionAdvertisingView
            inventory={institutionNetworkInventory}
            bookings={bookings}
            creatives={creatives}
            transactions={transactions}
            approvalHistory={approvalHistory}
            paymentsEnabled={featureFlags.payments}
            hasConflict={(inventoryId, start, end, excludeId) => { const booking = bookings.find((entry) => entry.id === excludeId); return hasCapacityConflict(inventoryId, start, end, booking?.adSlots ?? 1, excludeId, booking?.dayparts ?? []); }}
            updateBooking={updateBooking}
            updateMediaApproval={updateMediaApproval}
            onSettle={settleInvoice}
            onRunDelivery={runDeliveryTick}
            onOpenCommandCentre={(id) => { setSelectedInventoryId(id); navigateToView("network"); }}
            onEditScreen={(id) => { setSelectedInventoryId(id); navigateToView("inventory"); }}
          />
        );
      default:
        return null;
    }
  }

  if (view === "portal") {
    return (
      <Portal
        inventory={inventory}
        bookings={bookings}
        selectedLocation={selectedLocation}
        filters={filters}
        launch={launchPortal}
        selectFormat={selectFormat}
        currentUser={currentUser}
      />
    );
  }

  return (
    <div className={`shell${surface === "government" ? " government-shell" : ""}${navCollapsed ? " is-rail" : ""}`}>
      <Sidebar role={role} view={view} setRole={setRole} setView={navigateToView} currentUser={currentUser} surface={surface} collapsed={navCollapsed} onToggleCollapsed={toggleNavCollapsed} navigationLocked={campaignCreationActive} showAdvertising={showAdvertising} showFleetTools={showFleetTools} />
      <main className="workspace">
        <Topbar view={view} visibleCount={role === "advertiser" ? visibleInventory.length : inventory.length} inventory={inventory} bookings={bookings} role={role} surface={surface} campaignCreationLocked={campaignCreationActive} />
        {renderDashboardView()}
      </main>
    </div>
  );
}

function newInventoryTemplate(): InventoryItem {
  const availableFrom = new Date();
  const availableTo = new Date(availableFrom);
  availableTo.setUTCDate(availableTo.getUTCDate() + 90);
  return {
    id: "",
    name: "",
    operator: "",
    format: "digital",
    // The location picker opens on southern Ontario, not the middle of the
    // continent. The owner still pins the exact spot.
    x: ontarioLocation.x,
    y: ontarioLocation.y,
    // Start blank so the linear setup flow collects real device data instead
    // of carrying placeholder values into the review step or public page.
    address: "",
    price: 0,
    impressions: 0,
    traffic: 0,
    income: 0,
    audience: "",
    competitor: "Medium",
    occupancy: 0,
    imageInterval: 6,
    maxLoopSeconds: 120,
    availableFrom: availableFrom.toISOString().slice(0, 10),
    availableTo: availableTo.toISOString().slice(0, 10),
    approvalStatus: "pending approval",
    tags: [],
    displayTemplate: "fullscreen",
    displayLanguage: "en",
    deliveryMode: "digital",
    productType: "digital-screen",
    productionLeadDays: 0,
    installationLeadDays: 0,
  };
}

function creativeUploadForm(draft: CreativeDraft, file: File) {
  const form = new FormData();
  form.set("file", file);
  form.set("template", draft.template);
  form.set("format", draft.format);
  form.set("width", String(draft.width));
  form.set("height", String(draft.height));
  form.set("safeZone", String(draft.safeZone));
  form.set("distortion", String(draft.distortion));
  return form;
}

function compactFilters(filters: Partial<Filters> | undefined) {
  if (!filters) return {};
  return Object.fromEntries(Object.entries(filters).filter(([, value]) => value !== undefined)) as Partial<Filters>;
}

const documentTitleByView: Record<View, string> = {
  portal: "Outdoor media portal",
  network: "Public screen network control",
  emergency: "Emergency updates",
  discover: "Inventory discovery",
  booking: "Booking request",
  campaigns: "Campaign spaces",
  creative: "Creative production",
  resources: "Content management",
  inventory: "Inventory management",
  calendar: "Availability calendar",
  approvals: "Approval workflow",
  accounts: "Account management",
  reports: "Campaign analytics",
  billing: "Payments and billing",
  advertising: "Private-sector advertising",
  fleet: "Fleet tools",
};

function EmptyInventoryPanel({ canManage }: { canManage: boolean }) {
  const { t } = useI18n();
  return (
    <section className="panel">
      <EmptyState
        title={canManage ? "No screens yet" : "No screens are available yet"}
        copy={canManage
          ? "Add a device in Inventory to start selling media."
          : "Nobody has listed a screen for advertising yet. Check back soon, or ask the screen owner to list it."}
        action={canManage ? <a className="primary-button" href="/?view=inventory">{t("Open Inventory")}</a> : undefined}
      />
    </section>
  );
}
