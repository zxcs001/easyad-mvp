### Booking schedule: quick dates, budget and time of day

The Request dates step has one **When it runs** block. The helpers are pure functions in [`app/lib/booking-schedule.ts`](app/lib/booking-schedule.ts), and the fields are in [`app/component/booking-schedule-fields.tsx`](app/component/booking-schedule-fields.tsx).

- **Quick lengths.** `1 week`, `2 weeks` and `4 weeks` set the end date from the start date. A changed start date keeps the run length.
- **Availability calendar.** Five weeks of days: space open, few spots left, full and not available. Each state has a shape and a label as well as a colour. A click on a day moves the start there. The calendar reads `GET /api/inventory/{id}/availability`, which returns confirmed loop time with dates and slots only, and no advertiser names.
- **Next open dates.** When the chosen dates are full or in the past, the form offers the nearest run of the same length that fits, with a **Use these dates** button.
- **Start from a budget.** The person types a budget in CAD. The form sets the end date to the most whole days the budget pays for, and shows the total and what is left. A budget below one day blocks the request and says why.
- **Time of day.** Digital screens only. Morning, Midday, Afternoon drive, Evening and Overnight, in Toronto time. A slot costs its share of the daily rate, and all five cost the daily rate. Each slot has its own loop capacity. The rule, the prices and the playback behaviour are in [ADR 0009](docs/adr/0009-time-of-day-booking.md).

The booking API takes the slots as a `dayparts` form field (comma-separated, for example `morning,evening`). Run `npm run db:migrate` after deployment so the `bookings.dayparts` column exists.

Discover shows three filters by default and keeps the rest behind **More filters**, which remembers what you open (ADR 0008 stage 1). The control always shows how many hidden filters are active, and an active hidden filter opens the group, so disclosure never hides capability.

Every empty state names a next action, through the shared `EmptyState` in [`app/component/shared-ui.tsx`](app/component/shared-ui.tsx). A column header is never shown above an empty table.

A disabled control must state why it is disabled and what to do next. See the blocked-reason line in [`app/component/booking-view.tsx`](app/component/booking-view.tsx). A silent disabled control is a defect.

The portal at `/` serves two audiences from one component. A signed-out visitor sees the marketing page. A signed-in advertiser sees a task-focused home built by `AdvertiserHome` in [`app/component/portal.tsx`](app/component/portal.tsx). Role selects the branch; the screen is not forked. The civic gateway renders for both, because a test and [DESIGN.md](DESIGN.md) require it at the end of the page for every visitor.

Complexity varies inside the advertiser role as well as between roles. Advertiser density is disclosed progressively, and the interface remembers what a person opens instead of asking them to pick a level. Any mode has two settings, defaults to guided, and never applies to the operator, institution, or government consoles. [ADR 0008](docs/adr/0008-advertiser-complexity-modes.md) records that decision and its boundary.
