import type { Locale } from "./i18n/config";

export type FormatKey = "digital" | "static" | "transit";
export type DeliveryMode = "digital" | "static" | "unknown";
export type OrganizationType = "advertiser" | "agency" | "media_owner" | "institution" | "production_vendor" | "installation_vendor" | "platform";
export type MembershipRole = "owner" | "admin" | "planner" | "account_manager" | "designer" | "reviewer" | "operations" | "finance" | "viewer";
export type Role = "advertiser" | "operator" | "institutional" | "admin";
export type UserStatus = "active" | "banned";
export type View =
  | "portal"
  | "network"
  | "emergency"
  | "discover"
  | "booking"
  | "campaigns"
  | "creative"
  | "resources"
  | "inventory"
  | "calendar"
  | "approvals"
  | "accounts"
  | "reports"
  | "billing"
  | "advertising";

export type DisplayTemplate = "fullscreen" | "weather" | "public-info" | "transit" | "community";

export const displayTemplates: DisplayTemplate[] = ["fullscreen", "weather", "public-info", "transit", "community"];

export type InventoryItem = {
  building?: string; department?: string; contentVisibility?: "public"|"private"; advertisingOptIn?: boolean; restrictedCategories?: string[]; reservedSeconds?: number; fleetVersion?: number;
  id: string;
  name: string;
  operator: string;
  format: FormatKey;
  x: number;
  y: number;
  address: string;
  price: number;
  impressions: number;
  traffic: number;
  income: number;
  audience: string;
  competitor: "Low" | "Medium" | "High";
  occupancy: number;
  imageInterval: number;
  maxLoopSeconds: number;
  availableFrom: string;
  availableTo: string;
  approvalStatus?: "pending approval" | "approved" | "rejected";
  tags?: string[];
  displayTemplate?: DisplayTemplate;
  displayLanguage?: Locale;
  commentsEnabled?: boolean;
  institutionId?: string | null;
  ownerOrganizationId?: string | null;
  deliveryMode?: DeliveryMode;
  productType?: string;
  productionLeadDays?: number;
  installationLeadDays?: number;
  latitude?: number | null;
  longitude?: number | null;
  measurementSource?: string | null;
  measurementUpdatedAt?: string | null;
};

export type Organization = {
  id: string;
  name: string;
  type: OrganizationType;
  status: "active" | "inactive";
  defaultCurrency: "CAD";
  timezone: string;
};

export type InventorySpecification = {
  id: string;
  inventoryId: string;
  version: number;
  status: "active" | "retired";
  trimWidthMm: number | null;
  trimHeightMm: number | null;
  visibleWidthMm: number | null;
  visibleHeightMm: number | null;
  bleedMm: number | null;
  safeAreaMm: number | null;
  scaleRatio: string | null;
  minimumDpi: number | null;
  colourSpace: string | null;
  acceptedFileTypes: string[];
  maximumFileBytes: number | null;
  substrate: string | null;
  finishing: string | null;
  templateUrl: string | null;
  notes: string | null;
  createdAt: string;
};

export type InventoryComment = {
  id: string;
  inventoryId: string;
  authorId: string | null;
  authorName: string;
  body: string;
  createdAt: string;
};

export type MediaResource = {
  startsAt?: string|null; endsAt?: string|null; revision?: number;
  id: string;
  inventoryId: string;
  ownerId: string;
  title: string;
  originalName: string;
  mimeType: string;
  mediaType: "image" | "video" | "file";
  approvalStatus: "pending review" | "approved" | "rejected";
  sizeBytes: number;
  publicUrl: string;
  createdAt: string;
};

export type DeviceAlertType = "amber" | "weather" | "evacuation" | "public-safety";

export type DeviceAlert = {
  id: string;
  institutionId: string;
  alertType: DeviceAlertType;
  title: string;
  message: string;
  area: string;
  status: "active" | "ended";
  targetDeviceIds: string[];
  issuedBy: string;
  createdBy: string | null;
  createdAt: string;
  expiresAt: string;
  endedAt: string | null;
  image?: { url: string; mimeType: string; originalName: string; sizeBytes: number } | null;
};

export type Booking = {
  id: string;
  advertiser: string;
  inventoryId: string;
  campaign: string;
  start: string;
  end: string;
  adSlots: number;
  /** Time-of-day slots in Toronto time. Absent or empty means all day. */
  dayparts?: import("./lib/booking-schedule").DaypartId[];
  creativeStatus: "not submitted" | "approved" | "pending review" | "needs changes";
  status: "pending approval" | "creative review" | "approved" | "scheduled" | "live" | "completed" | "rejected" | "cancelled";
  spend: number;
  paid: boolean;
  pop: number;
  createdBy?: string;
};

export type ApprovalEvent = {
  id: string;
  bookingId: string;
  campaign: string;
  inventoryId: string;
  action: "approved" | "rejected";
  previousStatus: Booking["status"];
  nextStatus: Booking["status"];
  actorName: string;
  createdAt: string;
};

export type TransactionStatus = "pending" | "paid" | "refunded" | "failed";

export type Transaction = {
  id: string;
  bookingId: string;
  advertiser: string;
  amount: number;
  platformFee: number;
  operatorPayout: number;
  status: TransactionStatus;
  method: string;
  gatewayRef: string | null;
  createdAt: string;
  paidAt: string | null;
};

export type PopLog = {
  id: string;
  bookingId: string;
  inventoryId: string;
  plays: number;
  impressions: number;
  status: "verified" | "missed";
  source: string;
  playedAt: string;
};

export type Creative = {
  id: string;
  bookingId: string;
  source: "template" | "upload";
  template: "retail" | "finance" | "event";
  format: FormatKey;
  width: number;
  height: number;
  fileType: "png" | "jpg" | "gif" | "pdf" | "mp4" | "html";
  fileSize: number;
  safeZone: number;
  distortion: number;
  originalName: string | null;
  mimeType: string | null;
  publicUrl: string | null;
  status: "pending review" | "approved" | "needs changes";
  createdAt: string;
};

export type InventoryAdvertiserResource = Creative & {
  advertiser: string;
  campaign: string;
  start: string;
  end: string;
  bookingStatus: Booking["status"];
  dayparts?: Booking["dayparts"];
};

export const formats = {
  digital: {
    label: "Digital Screen",
    ratio: 16 / 9,
    spec: "1920 x 1080, JPG/PNG/MP4, 10s loop",
    maxSize: 250,
    safeZone: 8,
    priceMultiplier: 1.25,
  },
  static: {
    label: "Static Billboard",
    ratio: 4 / 1,
    spec: "5760 x 1440, PDF/JPG, CMYK ready",
    maxSize: 500,
    safeZone: 6,
    priceMultiplier: 1,
  },
  transit: {
    label: "Transit Panel",
    ratio: 3 / 1,
    spec: "3000 x 1000, PDF/JPG, 150 DPI",
    maxSize: 300,
    safeZone: 10,
    priceMultiplier: 0.8,
  },
} satisfies Record<FormatKey, {
  label: string;
  ratio: number;
  spec: string;
  maxSize: number;
  safeZone: number;
  priceMultiplier: number;
}>;

// Map locations (Ontario and its counties) live in app/lib/geo/regions.ts.
