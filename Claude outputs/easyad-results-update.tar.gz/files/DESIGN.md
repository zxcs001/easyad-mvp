---
version: alpha
name: "EasyAD Platform"
description: "A civic-infrastructure-inspired outdoor-media marketplace and operations console for advertisers, screen operators, institutions, and local government."
colors:
  background: "#F6F7F9"
  panel: "#FFFFFF"
  ink: "#0E141B"
  muted: "#5A6472"
  line: "#E5E8EC"
  line-strong: "#7A8391"
  control-edge: "#8A93A0"
  primary: "#0C7A56"
  primary-dark: "#08573D"
  info: "#2459B3"
  info-dark: "#1A428A"
  state-idle-surface: "#EFF1F4"
  state-idle-ink: "#5A6472"
  state-success-surface: "#E4F3EC"
  state-success-ink: "#08573D"
  state-warning-surface: "#FBEAB4"
  state-warning-ink: "#7A5510"
  state-danger: "#B3192E"
  state-danger-surface: "#FBE9EC"
  state-danger-ink: "#A11228"
  state-info-surface: "#EAF0FA"
  state-info-ink: "#1A428A"
  state-emergency-surface: "#1A1206"
  state-emergency-ink: "#FFC845"
  navigation: "#0A0E13"
  signal: "#34D399"
typography:
  sans:
    fontFamily: "Geist, Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif"
  mono:
    fontFamily: "Geist Mono, ui-monospace, SFMono-Regular, Consolas, monospace"
rounded:
  DEFAULT: "10px"
  sm: "8px"
  workspace-control: "7px"
  workspace-panel: "10px"
spacing:
  workspace-gap: "16px"
  section-gap: "28px"
  page-inline: "56px"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.panel}"
    rounded: "{rounded.workspace-control}"
  button-primary-hover:
    backgroundColor: "{colors.primary-dark}"
    textColor: "{colors.panel}"
  button-warning:
    backgroundColor: "{colors.warning}"
    textColor: "{colors.ink}"
  button-danger:
    backgroundColor: "{colors.danger}"
    textColor: "{colors.panel}"
  panel:
    backgroundColor: "{colors.panel}"
    textColor: "{colors.ink}"
    rounded: "{rounded.workspace-panel}"
  supporting-text:
    textColor: "{colors.muted}"
  divider:
    backgroundColor: "{colors.line}"
  information-status:
    backgroundColor: "{colors.info}"
    textColor: "{colors.panel}"
  navigation:
    backgroundColor: "{colors.navigation}"
    textColor: "{colors.panel}"
  map:
    backgroundColor: "{colors.background}"
  device-preview:
    backgroundColor: "{colors.navigation}"
    rounded: "{rounded.workspace-panel}"
---

# EasyAD Platform Design System

## Overview

### Creative North Star

The product should feel like a well-run municipal operations room crossed with a physical media-control rack: clear status lamps, geographic context, bounded control surfaces, and an unmistakable distinction between routine publishing and emergency interruption. The public portal may be expressive; authenticated operations stay calm and dense.

### Product context and register

- **Audience and primary job:** Advertisers find and book outdoor media; operators maintain inventory; institutions and local governments control their own screen fleets and public messages; super admins oversee the marketplace.
- **Target market(s) and evidence:** The current product data and seed inventory are Canadian and centered on Thunder Bay, Ontario. The interface remains broadly North American and English-first.
- **Locale(s) and language policy:** English (`en`) and Canadian French (`fr`) are active. English is the default, while Quebec-region requests default to French until the person explicitly chooses a language. The locale cookie is canonical across public and authenticated website routes. Standalone `/devices/[id]` playback instead uses the language saved on that device in the dashboard; owned copy, accessible names, dates, numbers, and CAD currency follow the applicable locale.
- **Usage scene:** Desktop-first planning and operations with responsive access on phones. Fleet and emergency controls are used in time-sensitive, high-attention situations.
- **Register:** Hybrid. The landing route is a brand/marketing surface; authenticated workspaces are product/admin surfaces. `/government/about` is the public civic-information surface, `/government/login` is the civic trust surface, and `/government` is a business-named operations-shell variant for institutions and local government.
- **Vocabulary by audience:** The product serves two populations with one component set. Operators, institutions, and government staff are trained, so their surfaces keep precise operational terms such as loop time and approval. The advertiser is often a small-business owner buying outdoor media for the first time, so advertiser surfaces name the task instead of the trade: screens, not inventory; your ad picture, not creative; how long it runs, not run length. The two vocabularies live in the same components and are selected by role, never by forking a screen.
- **Institution isolation:** The institution workspace is a screen-operations tool, not a sales tool. Each institution screen has one screen use: `Institution use only` (the default) or `Open to private-sector advertising`. The owner sets it per screen in the Command centre. While a screen is reserved, no surface shows its rate, occupancy, audience, booking dates, or billing. Commercial views (screens and rates, booking review, booking calendar, performance, billing) live in one `Advertising` entry. That entry appears only when a screen is open to advertising or advertising history remains. With every screen reserved, the Command centre and the Advertising route show a read-only note instead. Institution accounts do not see the marketplace portal or the advertising assistant. The screen-use state is neutral information, so it uses the idle status weight, never a severity colour.
- **Signed-in landing:** A signed-out visitor gets the marketing page. A signed-in advertiser has already accepted the pitch, so their landing surface answers "what do I do now" instead: their own state, the next task, and their bookings. The same component serves both and selects by role. The civic gateway stays on both, because the marketplace advertises the institution product only through that final band.
- **Density by need:** Complexity also varies inside the advertiser role, between a shop owner buying one screen and an agency buying for clients. Advertiser density is disclosed progressively and the choice is remembered, rather than asked for. Where a mode is offered it has exactly two settings, defaults to guided, and is named after the job rather than the person's skill. A complexity mode is forbidden on the operator, institution, and government consoles, because it is a mechanism for hiding controls and those surfaces must never hide permission limits or emergency scope. See [ADR 0008](docs/adr/0008-advertiser-complexity-modes.md).
- **Memorable signature:** A map-to-screen control surface: choosing a physical device immediately reveals a faithful 16:9 representation of what the screen is generally showing.
- **Restraint:** Forms, publishing controls, permission states, alerts, and data lists use familiar product patterns with minimal decoration.
- **Anti-references:** Avoid generic gradient-card SaaS dashboards, consumer-social visual language, hidden critical actions, and emergency controls that resemble routine campaign actions.
- **Token ownership/runtime mapping:** Existing runtime CSS is canonical (Model B). This file mirrors accepted values from [`app/globals.css`](app/globals.css); component CSS consumes those variables or documented compact workspace variants. Drift is checked through the premium static audit and rendered-screen review.

## Colors

`primary` and `primary-dark` identify safe primary actions, selection, and focus. `info` supports maps and neutral system information. `navigation` anchors the persistent operations shell.

Status is encoded by visual weight, not by hue. A colour-vision deficiency removes a hue channel, but it never removes lightness. Each state is therefore a surface-and-ink pair on a severity ladder, and each step is heavier than the step before it.

| Weight | State | Surface | Ink | Contrast |
|---|---|---|---|---|
| 0 | Idle, unpublished | `#EFF1F4` | `#5A6472` | 5.30:1 |
| 1 | Published, healthy | `#E4F3EC` | `#08573D` | 7.51:1 |
| 2 | Reversible caution | `#FBEAB4` | `#7A5510` | 5.59:1 |
| 3 | Destructive or failed | `#B3192E` | `#FFFFFF` | 6.78:1 |
| 4 | Active screen override | `#1A1206` | `#FFC845` | 12.00:1 |

Weight 4 is reserved. Use it for an active screen override only. A routine card must never borrow that urgency.

**Colour alone never encodes a state.** Four pale surfaces measure 1.00:1 apart under deuteranopia, so no palette separates them. Every state must also carry a distinct icon shape and a text label. This rule covers the healthy state, not only the warning and error states.

`line` is a decorative hairline at 1.23:1. It must never bound a control. Use `line-strong` for the edge of an input or a control, because it meets the 3:1 that WCAG 2.2 SC 1.4.11 requires.

`control-edge` is the resting edge of a text field, select, file input or outline button. It gives 3.11:1 on white, so it meets SC 1.4.11 by itself; `line-strong` stays the heavier edge. `signal` is decorative: it marks live lamps and glows on the dark navigation and the dark public heroes only, and never carries text.

The application is light-theme only today. Focus, text, and controls target WCAG 2.2 AA. Forced-colors mode must retain system-operable outlines and scrollbars. The measured basis for these tokens is in [ADR 0007](docs/adr/0007-status-colour-encoding.md).

## Typography

Geist is the canonical product face. Geist Mono is the technical face. Both ship in the `geist` package and load through `next/font/local` in `app/layout.tsx`, so no request goes to a font service. The CSS variables are `--font-sans` and `--font-mono`.

- Weights stay between 400 and 700. Headings use 600. Body text uses 400 to 500. Labels use 500 to 560. A weight of 800 or more is not used, because heavy Geist reads as loud, not precise.
- Display type tightens as it grows: `h1` uses -0.025em, `h2` and `h3` use -0.015em. The public hero may use scale for expression, at weight 600 to 700.
- Uppercase eyebrows, table headers, navigation group labels and stat-tile labels use Geist Mono at weight 500, 0.6rem to 0.68rem, with 0.08em tracking.
- Monospace also carries API paths, machine identifiers, codes, timestamps and tags.
- Numerical values use tabular figures where comparison matters.
- Labels use sentence case except the short uppercase eyebrows.

## Layout

The authenticated shell uses a 244px desktop sidebar and a natural-height document workspace. The sidebar collapses to a 76px icon rail. The choice is remembered rather than asked for, and a collapsed nav item keeps its label in the accessibility tree by clipping rather than removing it, so a screen reader still announces the destination. The rail applies from 901px up. At 900px and below the sidebar becomes a horizontal bar, the rail does not exist, and its toggle is hidden. A width-dependent rule is scoped to the breakpoint measured in the running layout, never to an assumed one. A control that undoes a state is never hidden at a width where that state can still apply. The Civic Screen Operations variant keeps that geometry and every shared workspace component, but replaces marketplace workspace switching with a fixed institution scope card, civic masthead, and government-route navigation. Panels use a 16px gap and compact internal padding. Map and preview surfaces own their bounded aspect or scroll behavior; they must not impose viewport height or overflow constraints on sibling forms. Public sections use up to 56px inline space at wide viewports and collapse to one column below the existing 900px breakpoint. The marketplace advertises the civic product only through a compact final-page gateway; detailed institutional positioning belongs to `/government/about`, keeping the top navigation focused on marketplace actions.

## Elevation & Depth

A section heading stacks its eyebrow above its title on one left edge, so every heading on a page starts at the same x. An eyebrow and a title must never be split to opposite ends of a band; titles differ in width, so the result reads as inconsistent alignment.

Hierarchy comes from tonal layers and hairline borders first, and from shadows last. Workspace panels use the faint `--workspace-shadow`; overlays use the large shared shadow. Maps and screen previews may sit one elevation above supporting controls. Static status blocks do not receive decorative floating shadows. Layers follow the shared z-index tokens in `globals.css`. The site assistant sits above page chrome and below every dialog backdrop and toast, so it never covers a decision or an acknowledgement. The assistant reports its own failures inside its panel.

## Shapes

Public surfaces use 8–12px radii. Dense workspace controls use 7px, fields use 8px and panels use 10px. Status pills may be fully rounded when they encode state; ordinary buttons do not become pills. Device previews preserve their physical screen aspect and use a modest frame radius.

## Components

### Foundational visual states

Every interactive component defines default, hover, focus-visible, active, disabled, and busy states without changing its footprint. Selection combines border, surface, and text/icon cues. Loading uses the app-owned spinner or stable pending copy; skeletons are not a default. Every state includes a distinct icon shape and a text label; colour alone never encodes a state. A map search screen uses two columns, not three. Filters sit in one horizontal bar across the top, the map holds the main column, and the result list holds the second. The detail for a selected item floats over the map's bottom corner, beside the pin it describes, rather than taking a column or a row of its own. Below 1120px the columns stack and the detail returns to normal flow, because a card floating over a narrow map would cover it. A click on a map pin and a click on a result card do the same thing: each selects the item and updates the one detail card. A map pin never opens a modal, because one click must change one surface. The detail card shows the screen's own 16:9 preview in place of a photograph. No photograph of a location exists, and a placeholder that no data can fill is not an image. A static billboard shows no preview, because a billboard shows no clock. The empty media area reads "Your ad plays here"; operator wording stays on the real public screen. Location comments sit inside the card, collapsed, so they are reachable from the list as well as from the map. The floating card stays inside the map and clear of the map search bar.

A step indicator names the steps and marks the current one. It never states a count the product cannot keep. A step that cannot be reached yet states the reason instead of leading to an empty screen. The steps stay on one line. A wrapped step reads as a second, separate sequence, so when the header is too narrow the summary stats move to their own row below the steps. The steps do not move, and the language menu stays at the top right beside the title.

A browse surface carries the figures a person decides on. Deeper attributes belong on the item's own profile, reachable by a link, so detail is deferred without capability being removed.

A scanning list carries only what a person scans by. Per-item attributes belong in the detail surface for the selected item, not repeated on every row.

An empty state names the next action. A screen that states only a rule leaves a person stuck, so the shared `EmptyState` carries a title, a plain-language explanation, and a control that takes the person to the step that fills it. A column header never renders above an empty table; it appears with the first row.

A long workspace page splits into section tabs (`WorkspaceTabs` in `app/component/workspace-tabs.tsx`) instead of stacking every panel. One tab list holds sections of one subject, the open tab shows one panel, and the selected tab is a raised white chip with a strong edge and heavier text. Arrow keys, Home and End move between tabs. Bulk work across many screens is its own page with two numbered steps: choose the screens, then choose one task. A selection carries across tasks; a task's result list does not. When the open tab matters after a reload, the address holds it.

A disabled control always states why it is disabled and what to do next, in the weight-2 caution pair, adjacent to the control and associated with `aria-describedby`. A control with more than one blocking condition names the condition that currently applies. A silent disabled control is a defect.

A booking schedule offers the common choice as one click and keeps the exact control beside it. Run lengths are pill presets above the date fields, and the preset that matches the dates shows as pressed. Planning by dates or by budget is a two-button segmented control; budget mode replaces the end date field with the budget field and states the dates and total the budget buys. Time-of-day slots are a grid of toggle cards with a check box shape, the hours and the price per day; "All day" is the default card, and clearing every slot returns to it. The availability calendar is a five-week grid. Each day state carries a surface, a shape and a text label: space open (plain), few spots left (warning surface and a half-filled dot), full (danger surface, a cross and a struck-through number), and not available (hatched and disabled). The chosen dates carry a green edge. When the chosen dates do not work, the form offers the nearest run of the same length with one button, under the blocked reason.

### Buttons and actions

Primary green is for the main safe action. The ghost button is a white outline with ink text and handles secondary work. The secondary button is near-black and handles a neutral action that needs weight. Hover changes the surface or the edge; a button does not lift or cast a shadow. The weight-2 amber pair identifies reversible caution. The weight-3 solid `state-danger` fill is reserved for destructive or high-impact final confirmation; its solid fill is what separates it from a routine action for a colour-blind operator. Busy labels retain control dimensions and block duplicate activation.

### Navigation and data display

The institutional screen dashboard keeps map selection, screen preview, location and display metadata together. Local fleet search matches name, address, ID, building and department without losing the selected screen. Clicking a visible pin keeps it in place; selecting an offscreen device from the list brings that device into view. During map initialization, a stable loading state holds the map area until one renderer is ready; interactive fallback pins never swap to WebGL pins after selection. Resource thumbnails show approval state, not proof of playback. Display settings use the shared dialog and native selects; server-confirmed saves update the selected screen without changing publication state. Full inventory and content management remain reachable from this context.

Marketplace maps open on Ontario and then move to the visitor's own location when the browser shares it; they never open on one fixed city. A region (the province or a county-level division) fits its bounds, lists every screen inside its boundary and draws no distance circle or search centre; the distance control is disabled with a visible reason. A point location draws the circle and centre. Map search lists places before screens and labels each place with its level ("County, Ontario"). Search providers are additive, so street-level results join the same list without a second search control.

The dark sidebar is the canonical authenticated navigation. Civic Screen Operations is its named government variant: it uses the same navy, green, and blue tokens with a building-and-status-lamp identifier and does not introduce a second palette. Current items use the green/blue selection wash and an accessible `aria-current`. The address follows the current view, so reload, Back, Forward and a shared link all land on the same view. In-app links keep a real `href` and switch the view in place only on a plain left click; a modified or middle click opens a new tab. Data lists retain stable row geometry and transform to stacked records when narrow. A table whose cells carry no labels does not stack, because its values lose their meaning; it keeps its header and scrolls sideways inside its panel, and never scrolls the page. The fleet map and device list remain synchronized to one selected device. At city scale, device locations use compact, accessible teardrop buttons without embedded labels so geographic context remains readable; neutral slate means unselected and primary green means selected, reinforced by accessible pressed state and the synchronized device list. Below city scale, individual device pins give way to green city-availability count markers anchored to one representative matching device. The visible marker shows only the device count, while its accessible name identifies the city and interaction; activating it centers and zooms into that city. The public portal uses an availability-only map variant: it shows available-device and city markers without selection, competitor markers, search-radius graphics, or campaign-status overlays.

The shared language control is embedded at the far right of public and authenticated top bars, directly after the primary top-bar action where present. Its compact trigger opens the complete language menu on hover, click, or keyboard focus; non-shell routes use the same component as a floating fallback. Standalone device playback is the deliberate exception: `/devices/[id]` contains no website language control or other interactive chrome, and its configured display language is managed from the inventory dashboard.

### Forms and overlays

Fields use shared border, radius, hover, and focus tokens. Native select and date popups are accepted for the current English/French product; their operating-system-owned popup geometry and localized presentation are part of the supported contract. App-owned validation and errors remain in-page. An address is four fields — street, city, province or territory, postal code — that carry the browser's own autofill names, and the block shows the composed line it will save before the person saves it. A refused save names the missing field and moves focus into it; it never disables the control without a reason. Dialogs use the shared modal primitive, stay within the visual viewport, trap focus, close with Escape when safe, and restore focus. Toasts are acknowledgements only.

### Iconography

Lucide is the canonical icon family, using consistent outline strokes. Icons reinforce labels; unfamiliar or high-impact actions always keep visible text.

### Motion

Motion communicates selection, entry, and confirmation at roughly 140–260ms. No perpetual decorative motion appears in the workspace. `prefers-reduced-motion` removes transforms and nonessential transitions.

### Content and data visualization

Copy names what people control: devices, screens, content, publishing, and emergency overrides. Status vocabulary stays literal (`Published`, `Unpublished`, `Active override`). The UI never implies that a screen-only emergency override has been issued through an official public-alerting system. A relayed official alert names its source (an Alert Ready tag in lists, "Alert Ready (NAAD System)" on the screen), and the relay panel states that EasyAD shows alerts and does not issue them. The relay choice is three radio cards (Off, Ask me first, Show automatically) with a sentence each; a mode that cannot act fully, such as automatic display without a signing certificate, says so in a caution note beside it. Each official alert row carries its delivery state, a Broadcast Immediately tag, its signature state with a distinct icon, and how many screens are in the area, marked approximate when a geocode was widened.

The advertiser's fixed-template editor starts with three finished 16:9 HTML examples: Retail's warm local shop promotion, Finance's calm service message, and Event's vivid live announcement. A visual gallery shows all three examples with a topic, name, and short description before selection. Selecting one loads its complete sample copy and art; each topic keeps its own edits while the advertiser switches between them. A responsive sandboxed preview sits above the editor; a disabled submit state and in-place error explain a failed safe preview. The design opens on plain fields named for what they hold (business name, headline, one more line, call to action, when, where), each with a character count, and a row of headline ideas fills the headline in one click. The fields build the design's own markup, so the layout cannot break; the last headline word takes the design's accent colour. The HTML source editor is a closed disclosure, "Edit the HTML instead (advanced)". Hand-edited HTML wins over the fields, and the fields then show as disabled with a caution note that says why and one button back. A ready-made design asks for no safe-zone or distortion numbers, because it is laid out inside the safe zone and never scaled. A glance test beside the output checks rates the words a passer-by reads (headline words, line length, total words, a next step) with a pass or caution shape and a label; it is advice and never blocks a submission. The source editor uses a monospace face and a clear reset action. Review, content library, and screen previews use the same stored HTML artifact, shown only through sandboxed frames.

Results name the source of every figure. A counted figure (QR scans and link visits) and a reported figure (promo-code use, labelled "you report") never share a label, and an estimate (views) carries its audience source and the words "not an audited measurement". Each campaign row shows responses, reported uses, cost per response, a 14-day bar strip with an accessible text summary, and three actions: edit the link, download the QR code, open the report. The printable report is one page with a print button that disappears in print, together with the site chrome.

## Do's and Don'ts

- **Do:** Make geographic selection, device status, and screen content legible in one view.
- **Do:** Visually separate routine content publishing from emergency interruption and require an explicit confirmation for the latter.
- **Don't:** Introduce a second token palette or fork the shared dashboard functionality for institutional tools; use the documented Civic Screen Operations shell variant.
- **Don't:** Hide permission limits, publish uncertainty, or alert scope behind icon-only controls or transient toasts.
